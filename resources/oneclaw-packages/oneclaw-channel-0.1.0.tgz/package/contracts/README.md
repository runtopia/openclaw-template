# OneClaw Runtime Channel Protocol v1

Protocol v1 is frozen at contract version `1.0.0` on 2026-07-31, against OpenClaw `2026.7.1`.

This directory is the canonical contract shared by the Runtime channel plugin, OneClaw API, iOS, and Desktop remote mode. Implementations may generate native models from the schemas, but must not maintain hand-edited protocol copies.

## Frozen surface

The machine-readable source of truth is:

- `manifest.v1.json`: version, entrypoints, enums, directions, compatibility policy, and semantic rule names.
- `schemas/*.v1.schema.json`: JSON Schema Draft 2020-12 structural contract.
- `fixtures/valid.*.v1.json`: payloads every implementation must accept.
- `fixtures/invalid.v1.json`: payloads every implementation must reject at the declared validation layer.
- `checksums.v1.sha256`: integrity hashes for the frozen manifest, schemas, and fixtures.

Canonical schema IDs use `https://schemas.oneclaw.ai/protocol/v1/`. They are identifiers, not permission to fetch schemas over the network. A validator must load every local schema into one registry by `$id`, then resolve references from that registry.

## Boundary and authority

OneClaw API allocates the public `workspaceId`, `sessionId`, `messageId`, `runId`, command IDs, delivery sequence, connection ID, and connection generation. `runId` is the stable public correlation and cancellation key. OpenClaw's internal identifier is optional `engineRunId` and is diagnostic only.

Runtime owns execution and publishes the resulting events. The authoritative event producers are:

| Event family | Producer |
|---|---|
| `message.*` | Reply Dispatcher for the inbound main reply; Message Publisher for atomic programmatic messages |
| `run.*` | Channel inbound/run controller |
| `task.snapshot` | `oneclaw-workflows` |
| `attention.*` | `request_user_input` adapter and Interaction Broker |
| `artifact.*` | Artifact or Workflow tool adapter |

API persists, indexes, and distributes events to clients. iOS and Desktop consume API projections; they do not infer protocol events by parsing assistant text.

## Transport

The Runtime opens the WebSocket and authenticates in the HTTP upgrade request:

```http
Authorization: Bearer <instance-token>
```

Credentials are forbidden in JSON frames. API assigns `connectionId` and the monotonic `generation`. Every post-handshake frame is fenced by both values; a frame from a stale connection is rejected.

Frames have a transport direction fixed in `manifest.v1.json`. `command.message.send` enters the per-session data lane. `command.attention.respond` and `command.run.cancel` are control-lane commands and bypass that FIFO so a waiting Run cannot block its own response or cancellation.

## Delivery, ACK, cursor, and failure

API assigns `deliverySequence` to commands. Runtime assigns `outboxSequence` to outbound events. Both are monotonic within one Runtime instance. Reconnect cursors are the highest gap-free contiguous terminal receipts, never merely the highest observed sequence.

`command.ack` and `event.ack` use:

- `accepted`: the receiver durably recorded ownership of the item.
- `duplicate`: the same stable ID and canonically equivalent semantic payload was already recorded.
- `rejected`: a permanent protocol rejection with a stable error; it is a terminal receipt.

All three statuses may close a sequence position after the receiver durably stores the result. A missing ACK, connection loss, or transient storage failure does not close it. Out-of-order receipts are retained, but the reconnect cursor advances only after every preceding sequence is terminal.

A rejected ACK always has `error.retryable = false`. Transient storage or availability failures do not emit a terminal ACK; they keep the sequence open and may publish `channel.error`.

An accepted command is not the same as a successful Run:

- validation or ownership failure before acceptance returns `command.ack(status="rejected")`;
- failure after durable acceptance but before Run start publishes `command.failed`;
- failure after `run.started` publishes `run.failed`.

Reusing an idempotency key with a different semantic payload is `duplicate_conflict`, never `duplicate`. Equality uses RFC 8785 JSON Canonicalization and SHA-256 over the projection frozen in `manifest.v1.json`: commands include `protocolVersion`, `type`, `commandId`, and `payload`; transport delivery and connection fields are excluded. Events canonicalize the complete Event Envelope, excluding the surrounding `event.publish` frame.

## Event ordering and snapshots

`EventEnvelope.sequence` is monotonic per Session and orders business events. `revision` is monotonic per logical resource. Runtime transport `outboxSequence` is independent and exists only for reliable delivery.

`message.delta` is optional incremental text. `message.completed` always contains the complete final Message snapshot, so a client can recover when every Delta is missing. Programmatic `sendText` creates one atomic completed Message and must not synthesize Deltas.

`task.snapshot`, terminal Attention events, Artifact events, and Run events carry authoritative snapshots. Envelope and payload workspace, Session, Run, resource identity, and revision must agree. These equality rules and connection fencing are stateful semantic validation beyond JSON Schema and are exercised by `invalid.v1.json`.

## Rich content and safe actions

Message content is an ordered array of typed blocks. Protocol v1 freezes:

`text`, `markdown`, `image`, `file`, `table`, `key_value`, `artifact`, `notice`, and `action`.

Complex blocks require `fallbackText`. Clients render a supported block natively. If a future block arrives through a tolerant storage boundary, a v1 client renders the Message-level `fallbackText`, preserves the raw payload for replay, and does not execute unknown actions.

Actions are declarative allow-listed values. Arbitrary URLs, tool names, shell commands, local file paths, and executable client instructions are outside the protocol.

`command.attention.respond` carries `expectedRevision` and exactly one response form: question `answers` or an approval `actionId`. This command and Run cancellation use the control lane.

## Attachments and Artifacts

Frames carry opaque `downloadRef`, `uploadRef`, and preview references, never Runtime paths or object-store credentials. Live byte-bearing Artifacts require a version, MIME type, byte size, lowercase SHA-256, download reference, and expiry. A consumer verifies expiry, configured size limit, MIME policy, and hash before use.

Signed URL resolution is an API operation outside the WebSocket protocol. Implementations must enforce bounded streaming, redirect policy, private-network blocking, and ownership again when resolving a reference.

## Compatibility policy

Protocol v1 is strict: schemas set `additionalProperties: false`, and unknown frames, events, fields, and enum values are rejected at the protocol boundary.

Contract version patches may only clarify documentation, add fixtures for existing behavior, or fix the validator without changing the set of accepted payloads. Any wire-shape, enum, requiredness, ordering, ACK, cursor, idempotency, direction, or ownership change requires a new protocol version and parallel entrypoints. A deployed Runtime and API must negotiate one exact `protocolVersion`.

## Validation

From the `@oneclaw/channel` source repository:

```bash
python3 -m pip install -r contracts/requirements.txt
python3 contracts/scripts/validate_contract.py
```

The validator checks schema meta-validity, all valid and invalid fixtures, semantic equality/fencing rules, manifest consistency, and frozen checksums. `pnpm contract:validate` is the local shortcut. CI runs this validator and an independent AJV 2020 TypeScript consumer test.

## Parallel implementation contract

Each implementation team pins the same repository revision and verifies `checksums.v1.sha256` before generating models.

- TypeScript: load all schemas by `$id` into a Draft 2020-12 validator; discriminate frames, events, and blocks on `type`.
- Go: compile the entire local schema registry using Draft 2020-12 support; preserve JSON integers as `int64`; validate before decoding into discriminated structs.
- Swift: decode `type` into explicit enums with associated payload models; store epoch milliseconds as `Int64`; run the valid and invalid fixture suites in XCTest and preserve raw block JSON for fallback rendering.

All implementations must pass the shared fixtures unchanged. Language-specific tests may add cases, but cannot weaken or reinterpret a shared case.
