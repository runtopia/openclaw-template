#!/usr/bin/env python3

from __future__ import annotations

import hashlib
import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from jsonschema import RefResolver
from jsonschema.validators import validator_for


CONTRACT_VERSION = "1.0.0"
CONTRACT_ROOT = Path(__file__).resolve().parents[1]
SCHEMAS_ROOT = CONTRACT_ROOT / "schemas"
FIXTURES_ROOT = CONTRACT_ROOT / "fixtures"
MANIFEST_PATH = CONTRACT_ROOT / "manifest.v1.json"
CHECKSUM_PATH = CONTRACT_ROOT / "checksums.v1.sha256"


@dataclass(frozen=True)
class ValidationFailure:
    case_id: str
    message: str


def load_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def load_schemas() -> dict[str, dict[str, Any]]:
    schemas: dict[str, dict[str, Any]] = {}
    for path in sorted(SCHEMAS_ROOT.glob("*.schema.json")):
        schema = load_json(path)
        schema_id = schema.get("$id")
        if not isinstance(schema_id, str) or not schema_id:
            raise ValueError(f"{path} has no non-empty $id")
        if schema_id in schemas:
            raise ValueError(f"duplicate schema $id: {schema_id}")
        validator_for(schema).check_schema(schema)
        schemas[schema_id] = schema
    if not schemas:
        raise ValueError("no Protocol v1 schemas found")
    return schemas


def listed_schema_paths() -> list[str]:
    return [
        path.relative_to(CONTRACT_ROOT).as_posix()
        for path in sorted(SCHEMAS_ROOT.glob("*.schema.json"))
    ]


def listed_fixture_paths() -> list[str]:
    return [
        path.relative_to(CONTRACT_ROOT).as_posix()
        for path in sorted(FIXTURES_ROOT.glob("*.json"))
    ]


def manifest_errors(
    manifest: dict[str, Any],
    schemas: dict[str, dict[str, Any]],
) -> list[str]:
    errors: list[str] = []
    expected_scalars = {
        "status": "frozen",
        "contractVersion": CONTRACT_VERSION,
        "protocolVersion": 1,
        "schemaVersion": 1,
        "canonicalBaseUri": "https://schemas.oneclaw.ai/protocol/v1/",
        "jsonSchemaDialect": "https://json-schema.org/draft/2020-12/schema",
        "openClawBaseline": "2026.7.1",
        "schemaCount": len(schemas),
        "fixtureSuiteCount": len(listed_fixture_paths()),
    }
    for key, expected in expected_scalars.items():
        if manifest.get(key) != expected:
            errors.append(f"manifest {key} must be {expected!r}")

    declared_schemas = manifest.get("schemas", [])
    if (
        not isinstance(declared_schemas, list)
        or len(declared_schemas) != len(set(declared_schemas))
        or set(declared_schemas) != set(listed_schema_paths())
    ):
        errors.append("manifest schemas must exactly cover the local schema paths")
    declared_fixtures = manifest.get("fixtures", [])
    if (
        not isinstance(declared_fixtures, list)
        or len(declared_fixtures) != len(set(declared_fixtures))
        or set(declared_fixtures) != set(listed_fixture_paths())
    ):
        errors.append("manifest fixtures must exactly cover the local fixture paths")

    schema_ids = set(schemas)
    entrypoints = manifest.get("entrypoints")
    if not isinstance(entrypoints, dict) or not entrypoints:
        errors.append("manifest entrypoints must be a non-empty object")
    elif not set(entrypoints.values()).issubset(schema_ids):
        errors.append("every manifest entrypoint must resolve to a local schema $id")

    frame_schema = schemas.get(
        "https://schemas.oneclaw.ai/protocol/v1/runtime-channel-frame",
        {},
    )
    actual_frame_types = {
        definition.get("properties", {}).get("type", {}).get("const")
        for definition in frame_schema.get("$defs", {}).values()
    }
    actual_frame_types.discard(None)
    if set(manifest.get("frameTypes", [])) != actual_frame_types:
        errors.append("manifest frameTypes must exactly match the frame schema")

    event_schema = schemas.get(
        "https://schemas.oneclaw.ai/protocol/v1/event-envelope",
        {},
    )
    actual_event_types = set(
        event_schema.get("properties", {}).get("type", {}).get("enum", [])
    )
    if set(manifest.get("eventTypes", [])) != actual_event_types:
        errors.append("manifest eventTypes must exactly match the event schema")

    common_schema = schemas.get(
        "https://schemas.oneclaw.ai/protocol/v1/common",
        {},
    )
    actual_error_codes = set(
        common_schema.get("$defs", {}).get("ErrorCode", {}).get("enum", [])
    )
    if set(manifest.get("errorCodes", [])) != actual_error_codes:
        errors.append("manifest errorCodes must exactly match the common schema")

    command_ack_statuses = set(
        common_schema.get("$defs", {}).get("CommandAckStatus", {}).get("enum", [])
    )
    event_ack_statuses = set(
        common_schema.get("$defs", {}).get("EventAckStatus", {}).get("enum", [])
    )
    if (
        command_ack_statuses != event_ack_statuses
        or set(manifest.get("ackStatuses", [])) != command_ack_statuses
    ):
        errors.append("manifest ackStatuses must match both ACK status schemas")

    block_schema = schemas.get(
        "https://schemas.oneclaw.ai/protocol/v1/message-block",
        {},
    )
    actual_block_types = {
        definition.get("properties", {}).get("type", {}).get("const")
        for definition in block_schema.get("$defs", {}).values()
    }
    actual_block_types.discard(None)
    if set(manifest.get("messageBlockTypes", [])) != actual_block_types:
        errors.append("manifest messageBlockTypes must exactly match the block schema")

    directions = manifest.get("directions")
    if not isinstance(directions, dict):
        errors.append("manifest directions must be an object")
    else:
        direction_sets = [
            set(directions.get("runtimeToApi", [])),
            set(directions.get("apiToRuntime", [])),
            set(directions.get("bidirectional", [])),
        ]
        if any(
            left & right
            for index, left in enumerate(direction_sets)
            for right in direction_sets[index + 1 :]
        ):
            errors.append("manifest direction groups must not overlap")
        if set().union(*direction_sets) != actual_frame_types:
            errors.append("manifest direction groups must cover every frame type")

    expected_idempotency = {
        "canonicalization": "RFC 8785 JSON Canonicalization Scheme",
        "digest": "SHA-256",
        "commandProjection": [
            "protocolVersion",
            "type",
            "commandId",
            "payload",
        ],
        "eventProjection": "complete EventEnvelope",
        "excludedTransportFields": [
            "connectionId",
            "generation",
            "deliverySequence",
            "outboxSequence",
            "issuedAt",
        ],
    }
    if manifest.get("idempotency") != expected_idempotency:
        errors.append("manifest idempotency projection must match Protocol v1")

    semantic_rules = manifest.get("semanticRules")
    if (
        not isinstance(semantic_rules, list)
        or len(semantic_rules) != len(set(semantic_rules))
        or not all(isinstance(rule, str) and rule for rule in semantic_rules)
    ):
        errors.append("manifest semanticRules must be unique non-empty strings")

    return errors


def checksum_errors(manifest: dict[str, Any]) -> list[str]:
    if not CHECKSUM_PATH.is_file():
        return ["checksums.v1.sha256 is missing"]

    expected_paths = {
        "manifest.v1.json",
        *manifest.get("schemas", []),
        *manifest.get("fixtures", []),
    }
    declared: dict[str, str] = {}
    errors: list[str] = []
    for line_number, raw_line in enumerate(
        CHECKSUM_PATH.read_text(encoding="utf-8").splitlines(),
        start=1,
    ):
        if not raw_line:
            continue
        parts = raw_line.split("  ", maxsplit=1)
        if (
            len(parts) != 2
            or len(parts[0]) != 64
            or any(character not in "0123456789abcdef" for character in parts[0])
        ):
            errors.append(f"invalid checksum line {line_number}")
            continue
        digest, relative_path = parts
        if relative_path in declared:
            errors.append(f"duplicate checksum path {relative_path}")
            continue
        declared[relative_path] = digest

    if set(declared) != expected_paths:
        missing = sorted(expected_paths - set(declared))
        extra = sorted(set(declared) - expected_paths)
        errors.append(f"checksum path set mismatch; missing={missing}, extra={extra}")
        return errors

    contract_root = CONTRACT_ROOT.resolve()
    for relative_path, expected_digest in declared.items():
        path = (CONTRACT_ROOT / relative_path).resolve()
        if contract_root not in path.parents:
            errors.append(f"checksum path escapes contract root: {relative_path}")
            continue
        if not path.is_file():
            errors.append(f"checksummed file is missing: {relative_path}")
            continue
        actual_digest = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual_digest != expected_digest:
            errors.append(f"checksum mismatch: {relative_path}")
    return errors


def schema_errors(
    schemas: dict[str, dict[str, Any]],
    schema_id: str,
    value: Any,
) -> list[str]:
    schema = schemas.get(schema_id)
    if schema is None:
        return [f"unknown schemaId {schema_id}"]
    validator_class = validator_for(schema)
    validator = validator_class(
        schema,
        resolver=RefResolver.from_schema(schema, store=schemas),
    )
    errors = sorted(validator.iter_errors(value), key=lambda error: list(error.path))
    return [
        f"{'/'.join(str(part) for part in error.absolute_path) or '<root>'}: {error.message}"
        for error in errors
    ]


def semantic_errors(value: Any, context: dict[str, Any] | None = None) -> list[str]:
    if not isinstance(value, dict):
        return []

    errors: list[str] = []
    context = context or {}
    frame_type = value.get("type")

    authorized_workspace_id = context.get("authorizedWorkspaceId")
    if authorized_workspace_id is not None:
        candidate_workspace_id = value.get("workspaceId")
        payload = value.get("payload")
        if isinstance(payload, dict):
            candidate_workspace_id = payload.get(
                "workspaceId",
                candidate_workspace_id,
            )
        event = value.get("event")
        if isinstance(event, dict):
            candidate_workspace_id = event.get(
                "workspaceId",
                candidate_workspace_id,
            )
        if candidate_workspace_id != authorized_workspace_id:
            errors.append("ownership_mismatch")

    if "connectionId" in value and "generation" in value:
        active_connection_id = context.get("activeConnectionId")
        active_generation = context.get("activeGeneration")
        if (
            active_connection_id is not None
            and value["connectionId"] != active_connection_id
        ):
            errors.append("connection_generation")
        if active_generation is not None and value["generation"] != active_generation:
            errors.append("connection_generation")

    if frame_type == "event.publish":
        errors.extend(semantic_errors(value.get("event"), context))
        return sorted(set(errors))

    if frame_type == "channel.connect":
        for cursor_name, sequence_context_name in (
            (
                "lastContiguousCommandSequence",
                "terminalCommandSequences",
            ),
            (
                "lastContiguousEventSequence",
                "terminalEventSequences",
            ),
        ):
            sequences = context.get(sequence_context_name)
            if not isinstance(sequences, list):
                continue
            highest_contiguous = 0
            for sequence in sorted(set(sequences)):
                if sequence == highest_contiguous + 1:
                    highest_contiguous = sequence
                elif sequence > highest_contiguous + 1:
                    break
            if value.get(cursor_name) != highest_contiguous:
                errors.append("contiguous_cursor")

    if frame_type in {
        "command.message.send",
        "command.attention.respond",
        "command.run.cancel",
    }:
        recorded_key = context.get("recordedIdempotencyKey")
        recorded_material = context.get("recordedCommandMaterial")
        if (
            recorded_key is not None
            and recorded_key == value.get("idempotencyKey")
            and recorded_material is not None
        ):
            current_material = {
                "protocolVersion": value.get("protocolVersion"),
                "type": frame_type,
                "commandId": value.get("commandId"),
                "payload": value.get("payload"),
            }
            if current_material != recorded_material:
                errors.append("idempotency_payload_consistency")

    if frame_type == "command.message.send":
        payload = value.get("payload")
        attachments = (
            payload.get("attachments", [])
            if isinstance(payload, dict)
            else []
        )
        now = context.get("now")
        observed_hashes = context.get("observedAttachmentSha256", {})
        for attachment in attachments:
            if not isinstance(attachment, dict):
                continue
            if isinstance(now, int) and attachment.get("expiresAt", now) <= now:
                errors.append("attachment_expired")
            attachment_id = attachment.get("id")
            if (
                isinstance(observed_hashes, dict)
                and attachment_id in observed_hashes
                and observed_hashes[attachment_id] != attachment.get("sha256")
            ):
                errors.append("attachment_hash_mismatch")

    if not isinstance(frame_type, str) or "." not in frame_type:
        return sorted(set(errors))

    event_types = {
        "message.created",
        "message.delta",
        "message.completed",
        "message.failed",
        "task.snapshot",
        "attention.created",
        "attention.resolved",
        "attention.expired",
        "attention.cancelled",
        "attention.lost",
        "artifact.created",
        "artifact.updated",
        "run.started",
        "run.updated",
        "run.completed",
        "run.failed",
        "run.cancelled",
    }
    if frame_type not in event_types:
        return sorted(set(errors))

    payload = value.get("payload")
    if not isinstance(payload, dict):
        return sorted(set(errors))

    authoritative_resource_types = {
        "message.created",
        "message.completed",
        "task.snapshot",
        "attention.created",
        "attention.resolved",
        "attention.expired",
        "attention.cancelled",
        "attention.lost",
        "artifact.created",
        "artifact.updated",
        "run.started",
        "run.updated",
        "run.completed",
        "run.failed",
        "run.cancelled",
    }
    if frame_type in authoritative_resource_types:
        identity_keys = (
            ("workspaceId", "sessionId")
            if frame_type.startswith("run.")
            else ("workspaceId", "sessionId", "runId")
        )
        for key in identity_keys:
            if payload.get(key) != value.get(key):
                errors.append("event_resource_identity")
        if payload.get("revision") != value.get("revision"):
            errors.append("event_resource_revision")

    if frame_type.startswith("run.") and payload.get("id") != value.get("runId"):
        errors.append("event_resource_identity")

    return sorted(set(errors))


def validate_fixture_suite(
    path: Path,
    schemas: dict[str, dict[str, Any]],
    seen_case_ids: set[str],
    known_semantic_rules: set[str],
) -> tuple[int, list[ValidationFailure]]:
    suite = load_json(path)
    if suite.get("contractVersion") != CONTRACT_VERSION:
        return 0, [
            ValidationFailure(
                path.name,
                f"contractVersion must be {CONTRACT_VERSION}",
            )
        ]

    expected_valid = suite.get("expectedValid")
    if not isinstance(expected_valid, bool):
        return 0, [
            ValidationFailure(path.name, "expectedValid must be a boolean"),
        ]

    cases = suite.get("cases")
    if not isinstance(cases, list) or not cases:
        return 0, [
            ValidationFailure(path.name, "cases must be a non-empty array"),
        ]

    failures: list[ValidationFailure] = []
    for case in cases:
        case_id = case.get("id")
        if not isinstance(case_id, str) or not case_id:
            failures.append(ValidationFailure(path.name, "fixture case has no id"))
            continue
        if case_id in seen_case_ids:
            failures.append(ValidationFailure(case_id, "duplicate fixture case id"))
            continue
        seen_case_ids.add(case_id)

        schema_id = case.get("schemaId")
        value = case.get("value")
        structural = schema_errors(schemas, schema_id, value)
        semantic = semantic_errors(value, case.get("context"))

        if expected_valid:
            if structural:
                failures.append(
                    ValidationFailure(
                        case_id,
                        f"expected schema-valid: {' | '.join(structural)}",
                    )
                )
            if semantic:
                failures.append(
                    ValidationFailure(
                        case_id,
                        f"expected semantic-valid: {', '.join(semantic)}",
                    )
                )
            continue

        validation_layer = case.get("validationLayer")
        expected_rule = case.get("expectedRule")
        if validation_layer == "schema":
            if not structural:
                failures.append(
                    ValidationFailure(
                        case_id,
                        f"expected schema rejection for {expected_rule}",
                    )
                )
        elif validation_layer == "semantic":
            if expected_rule not in known_semantic_rules:
                failures.append(
                    ValidationFailure(
                        case_id,
                        f"semantic rule {expected_rule} is absent from the manifest",
                    )
                )
            if structural:
                failures.append(
                    ValidationFailure(
                        case_id,
                        f"semantic fixture must first pass schema: {' | '.join(structural)}",
                    )
                )
            if expected_rule not in semantic:
                failures.append(
                    ValidationFailure(
                        case_id,
                        f"expected semantic rule {expected_rule}, got {semantic}",
                    )
                )
        else:
            failures.append(
                ValidationFailure(
                    case_id,
                    "invalid fixture must declare validationLayer schema or semantic",
                )
            )

    return len(cases), failures


def main() -> int:
    schemas = load_schemas()
    manifest = load_json(MANIFEST_PATH)
    contract_failures = [
        ValidationFailure("manifest", message)
        for message in manifest_errors(manifest, schemas)
    ]
    fixture_files = sorted(FIXTURES_ROOT.glob("*.json"))
    if not fixture_files:
        print("No fixture suites found.", file=sys.stderr)
        return 1

    seen_case_ids: set[str] = set()
    case_count = 0
    failures: list[ValidationFailure] = []
    for path in fixture_files:
        count, suite_failures = validate_fixture_suite(
            path,
            schemas,
            seen_case_ids,
            set(manifest.get("semanticRules", [])),
        )
        case_count += count
        failures.extend(suite_failures)

    if manifest.get("fixtureCaseCount") != case_count:
        contract_failures.append(
            ValidationFailure(
                "manifest",
                f"fixtureCaseCount must be {case_count}",
            )
        )
    contract_failures.extend(
        ValidationFailure("checksums", message)
        for message in checksum_errors(manifest)
    )
    failures = contract_failures + failures

    if failures:
        for failure in failures:
            print(f"FAIL {failure.case_id}: {failure.message}", file=sys.stderr)
        print(
            f"Protocol v1 validation failed: {len(failures)} failure(s).",
            file=sys.stderr,
        )
        return 1

    print(
        f"Protocol v1 contract valid: {len(schemas)} schemas, "
        f"{len(fixture_files)} fixture suites, {case_count} cases."
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
