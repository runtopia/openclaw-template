# @oneclaw/runtime-events

Transport-independent Runtime business event SDK for Protocol v1.

It validates producer ownership and event metadata, derives stable
`(resourceId, revision, eventType)` idempotency keys, and publishes through one
process-global sink stored at `Symbol.for("@oneclaw/runtime-events")`.

The SDK has no OpenClaw Core, Channel transport, or OneClaw API dependency.
