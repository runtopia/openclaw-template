export type RuntimeEventProducer = 'artifact' | 'attention' | 'run-controller' | 'workflow';

export type RuntimeBusinessEventType =
  | 'artifact.created'
  | 'artifact.updated'
  | 'attention.cancelled'
  | 'attention.created'
  | 'attention.expired'
  | 'attention.lost'
  | 'attention.resolved'
  | 'run.cancelled'
  | 'run.completed'
  | 'run.failed'
  | 'run.started'
  | 'run.updated'
  | 'task.snapshot';

export type JsonPrimitive = boolean | null | number | string;
export interface JsonObject {
  [key: string]: JsonValue;
}
export type JsonValue = JsonObject | JsonPrimitive | JsonValue[];

export interface RuntimeBusinessEvent {
  type: RuntimeBusinessEventType;
  producer: RuntimeEventProducer;
  runId: string;
  resourceId: string;
  revision: number;
  payload: JsonObject;
  toolCallId?: string;
  occurredAt?: number;
}

export interface ValidatedRuntimeBusinessEvent extends RuntimeBusinessEvent {
  idempotencyKey: string;
}

export type PublishReceipt =
  | {
      status: 'accepted' | 'duplicate';
      eventId: string;
      idempotencyKey: string;
    }
  | {
      status: 'pending';
      idempotencyKey: string;
      reason: string;
    };

export interface RuntimeEventPublisher {
  publish(event: ValidatedRuntimeBusinessEvent): Promise<PublishReceipt> | PublishReceipt;
}

export interface SinkRegistration {
  dispose(): boolean;
}

export function validateRuntimeBusinessEvent(event: RuntimeBusinessEvent): ValidatedRuntimeBusinessEvent;
export function registerSink(sink: RuntimeEventPublisher): SinkRegistration;
export function publish(event: RuntimeBusinessEvent): Promise<PublishReceipt>;
export function runtimeEventSdkVersion(): '0.1.0';
