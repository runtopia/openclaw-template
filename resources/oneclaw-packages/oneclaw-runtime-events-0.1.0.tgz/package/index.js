const SDK_VERSION = '0.1.0';
const REGISTRY_KEY = Symbol.for('@oneclaw/runtime-events');

const EVENT_OWNERS = Object.freeze({
  'task.snapshot': 'workflow',
  'attention.created': 'attention',
  'attention.resolved': 'attention',
  'attention.expired': 'attention',
  'attention.cancelled': 'attention',
  'attention.lost': 'attention',
  'artifact.created': 'artifact',
  'artifact.updated': 'artifact',
  'run.started': 'run-controller',
  'run.updated': 'run-controller',
  'run.completed': 'run-controller',
  'run.failed': 'run-controller',
  'run.cancelled': 'run-controller',
});

const IDENTIFIER = /^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$/u;

function registry() {
  const existing = globalThis[REGISTRY_KEY];
  if (existing) {
    if (existing.sdkVersion !== SDK_VERSION) {
      throw new Error(`@oneclaw/runtime-events registry version mismatch: ${existing.sdkVersion} != ${SDK_VERSION}`);
    }
    return existing;
  }
  const created = {
    sdkVersion: SDK_VERSION,
    sink: undefined,
    token: undefined,
  };
  globalThis[REGISTRY_KEY] = created;
  return created;
}

function requireIdentifier(value, field) {
  if (typeof value !== 'string' || !IDENTIFIER.test(value)) {
    throw new TypeError(`${field} must be a Protocol v1 identifier`);
  }
  return value;
}

function assertJson(value, path = 'payload') {
  if (
    value === null ||
    typeof value === 'string' ||
    typeof value === 'boolean' ||
    (typeof value === 'number' && Number.isFinite(value))
  ) {
    return;
  }
  if (Array.isArray(value)) {
    value.forEach((entry, index) => assertJson(entry, `${path}[${index}]`));
    return;
  }
  if (typeof value === 'object' && Object.getPrototypeOf(value) === Object.prototype) {
    for (const [key, entry] of Object.entries(value)) {
      assertJson(entry, `${path}.${key}`);
    }
    return;
  }
  throw new TypeError(`${path} is not JSON-compatible`);
}

function expectedStatus(type) {
  if (type === 'attention.created') return 'pending';
  if (type === 'attention.resolved') return 'resolved';
  if (type === 'attention.expired') return 'expired';
  if (type === 'attention.cancelled') return 'cancelled';
  if (type === 'attention.lost') return 'lost';
  if (type === 'run.started') return 'running';
  if (type === 'run.completed') return 'completed';
  if (type === 'run.failed') return 'failed';
  if (type === 'run.cancelled') return 'cancelled';
  return undefined;
}

export function validateRuntimeBusinessEvent(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) {
    throw new TypeError('Runtime business event must be an object');
  }
  const owner = EVENT_OWNERS[value.type];
  if (!owner) {
    throw new TypeError(`Unsupported Runtime business event type: ${String(value.type)}`);
  }
  if (value.producer !== owner) {
    throw new TypeError(`${value.type} is owned by producer ${owner}, not ${String(value.producer)}`);
  }
  const runId = requireIdentifier(value.runId, 'runId');
  const resourceId = requireIdentifier(value.resourceId, 'resourceId');
  if (!Number.isSafeInteger(value.revision) || value.revision < 1) {
    throw new TypeError('revision must be a positive safe integer');
  }
  if (value.occurredAt !== undefined && (!Number.isSafeInteger(value.occurredAt) || value.occurredAt < 0)) {
    throw new TypeError('occurredAt must be a non-negative epoch millisecond');
  }
  if (value.toolCallId !== undefined) {
    requireIdentifier(value.toolCallId, 'toolCallId');
  }
  if (!value.payload || typeof value.payload !== 'object' || Array.isArray(value.payload)) {
    throw new TypeError('payload must be a JSON object');
  }
  assertJson(value.payload);
  const status = expectedStatus(value.type);
  if (status && value.payload.status !== undefined && value.payload.status !== status) {
    throw new TypeError(`${value.type} payload status must be ${status}`);
  }
  const idempotencyKey = `${resourceId}:${value.revision}:${value.type}`;
  return Object.freeze({
    type: value.type,
    producer: value.producer,
    runId,
    resourceId,
    revision: value.revision,
    idempotencyKey,
    payload: Object.freeze({ ...value.payload }),
    ...(value.toolCallId ? { toolCallId: value.toolCallId } : {}),
    ...(value.occurredAt !== undefined ? { occurredAt: value.occurredAt } : {}),
  });
}

export function registerSink(sink) {
  if (!sink || typeof sink.publish !== 'function') {
    throw new TypeError('Runtime event sink must expose publish(event)');
  }
  const state = registry();
  if (state.sink && state.sink !== sink) {
    throw new Error('A OneClaw Runtime event sink is already registered');
  }
  const token = Symbol('runtime-event-sink');
  state.sink = sink;
  state.token = token;
  return Object.freeze({
    dispose() {
      if (state.token !== token) return false;
      state.sink = undefined;
      state.token = undefined;
      return true;
    },
  });
}

export async function publish(value) {
  const event = validateRuntimeBusinessEvent(value);
  const sink = registry().sink;
  if (!sink) {
    return {
      status: 'pending',
      idempotencyKey: event.idempotencyKey,
      reason: 'sink_unavailable',
    };
  }
  try {
    return await sink.publish(event);
  } catch (error) {
    return {
      status: 'pending',
      idempotencyKey: event.idempotencyKey,
      reason: error instanceof Error ? error.message.slice(0, 300) : String(error).slice(0, 300),
    };
  }
}

export function runtimeEventSdkVersion() {
  return SDK_VERSION;
}
