const PAGE_ACTIONS = new Set(['focus', 'close', 'snapshot', 'screenshot', 'navigate', 'act', 'pdf', 'console', 'upload', 'dialog', 'resize']);
const ID = /^[A-Za-z0-9_-]{1,128}$/;

export function browserDisplayUrl(value) {
  try {
    const url = new URL(value);
    if (url.protocol === 'about:') return url.pathname === 'blank' ? 'about:blank' : undefined;
    if (!['https:', 'http:'].includes(url.protocol)) return undefined;
    return url.origin; // Paths, queries and fragments may contain login credentials.
  } catch { return undefined; }
}

// Logical task targets share one Chromium, never its global lastTargetId.
export function createBrowserWork({ file, now = Date.now } = {}) {
  const sessions = new Map();
  let current;
  let revision = 0;
  const key = (context) => context?.sessionKey || context?.sessionId || '';
  if (file && fs.existsSync(file)) {
    try {
      const saved = JSON.parse(fs.readFileSync(file, 'utf8'));
      for (const item of saved.sessions || []) {
        if (typeof item.sessionKey !== 'string' || !ID.test(item.targetId)) continue;
        // Chromium belonged to the previous Gateway process. Never claim an
        // old CDP target is still live after restart; keep only task metadata.
        const work = { sessionKey: item.sessionKey, targetId: item.targetId,
          displayUrl: browserDisplayUrl(item.displayUrl), phase: 'expired', targets: [], updatedAt: item.updatedAt };
        sessions.set(work.sessionKey, work);
        current = work;
        if (sessions.size >= 128) break;
      }
    } catch { /* Unrecognized live tabs remain unmanaged and prevent idle stop. */ }
  }
  function persist() {
    revision++;
    if (!file) return;
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const temp = `${file}.${process.pid}.tmp`;
    fs.writeFileSync(temp, JSON.stringify({ sessions: [...sessions.values()] }), { mode: 0o600 });
    fs.renameSync(temp, file);
  }
  const copy = (work) => {
    if (!work) return null;
    const result = Object.fromEntries(Object.entries(work).filter(([field]) => field !== 'targets'));
    // Preview identity is independent of the legacy handback/continuation signal.
    if (work.runId) result.previewRunId = work.runId;
    // Legacy clients use runId as their continuation signal. Inspecting a
    // completed page must not repeat its login/query/action after handback.
    if (work.needsContinuation === false) delete result.runId;
    return result;
  };
  function prepare(params, context) {
    const sessionKey = key(context);
    const bound = sessions.get(sessionKey);
    if (params.action === 'open' && !bound && sessions.size >= 128) {
      const expired = [...sessions].find(([, task]) => task.phase === 'expired');
      if (!expired) throw new Error('Browser Use: too many live conversation tabs. Close an existing task tab first.');
      sessions.delete(expired[0]);
    }
    if (!PAGE_ACTIONS.has(params.action)) return params;
    const explicit = params.targetId || params.request?.targetId;
    const targetId = explicit || (bound?.phase !== 'expired' ? bound?.targetId : undefined);
    if (!targetId || !ID.test(targetId)) throw new Error('Browser Use: select a task tab explicitly with targetId, or open a new task tab first. Do not use the shared browser default tab.');
    for (const [owner, work] of sessions) {
      if (owner !== sessionKey && work.targets.includes(targetId)) throw new Error('Browser Use: this tab belongs to another conversation. Open a separate task tab.');
    }
    return { ...params, targetId, ...(params.request ? { request: { ...params.request, targetId } } : {}) };
  }
  function complete(event, context, controlMode = 'ai') {
    const sessionKey = key(context);
    if (!sessionKey || event.toolName !== 'browser') return;
    const prior = sessions.get(sessionKey);
    const params = event.params || {};
    const details = event.result?.details || {};
    // A policy veto did not execute or focus this page. It must not transfer
    // another conversation's target into this task's ownership metadata.
    if (details.status === 'blocked' || details.deniedReason === 'plugin-before-tool-call') return;
    const failed = Boolean(event.error || event.result?.isError);
    if (params.action === 'close' && !failed) {
      if (prior) {
        prior.targets = prior.targets.filter(id => id !== params.targetId);
        if (!prior.targets.length) prior.phase = 'expired';
        else if (prior.targetId === params.targetId) prior.targetId = prior.targets.at(-1);
        prior.updatedAt = now();
        persist();
      }
      return;
    }
    const targetId = details.targetId || params.targetId || prior?.targetId;
    if (!targetId || !ID.test(targetId)) return;
    const work = {
      sessionKey, runId: event.runId || context?.runId, targetId,
      targets: [...new Set([...(prior?.targets || []), targetId])], retained: prior?.retained === true,
      needsContinuation: controlMode !== 'ai' && prior?.needsContinuation === true,
      displayUrl: browserDisplayUrl(details.url) || prior?.displayUrl,
      phase: failed ? 'failed' : 'working',
      action: params.action, updatedAt: now(),
      ...(failed ? { errorCode: 'browser_operation_failed' } : {}),
    };
    sessions.set(sessionKey, work);
    current = work;
    persist();
  }
  function finish(event, context) {
    const task = sessions.get(key(context));
    if (!task || task.phase === 'expired' || (context?.runId && context.runId !== task.runId)) return;
    task.phase = /abort|cancel/i.test(event.error || '') ? 'cancelled' : task.needsContinuation ? 'waiting_user' : event.success === false ? 'failed' : 'completed';
    if (task.phase !== 'waiting_user') task.needsContinuation = false;
    task.updatedAt = now();
    persist();
  }
  function touch(context) {
    const task = sessions.get(key(context));
    if (!task || task.phase === 'expired') return;
    task.phase = 'working'; if (context?.runId) task.runId = context.runId; task.updatedAt = now(); task.needsContinuation = false;
    persist();
  }
  function retain() {
    // Human input can visit any tab in the shared desktop. Protect all live
    // tabs, rather than guessing which page contains an unfinished user edit.
    for (const task of sessions.values()) if (task.targets.length) task.retained = true;
    if (current) current.needsContinuation = ['working', 'waiting_user'].includes(current.phase);
    persist();
  }
  function waiting(context) {
    const task = sessions.get(key(context));
    if (!task || task.phase === 'expired') return;
    task.phase = 'waiting_user'; task.needsContinuation = true; persist();
  }
  function idleCandidate(idleMs) {
    const live = [...sessions.values()].filter(task => task.targets.length);
    if (!live.length || live.some(task => task.phase !== 'completed' || task.retained || now() - task.updatedAt < idleMs)) return null;
    return { revision, targetIds: live.flatMap(task => task.targets) };
  }
  function expire() {
    for (const task of sessions.values()) { task.phase = 'expired'; task.targets = []; task.needsContinuation = false; delete task.runId; }
    persist();
  }
  function select(sessionKey) {
    const task = sessions.get(sessionKey);
    if (!task || task.phase === 'expired') throw new Error('This conversation has no live browser task');
    current = task; task.updatedAt = now(); persist();
    return copy(task);
  }
  return { prepare, complete, finish, touch, retain, waiting, idleCandidate, expire, select, status: (sessionKey) => copy(sessionKey ? sessions.get(sessionKey) : current) };
}
import fs from 'node:fs';
import path from 'node:path';
