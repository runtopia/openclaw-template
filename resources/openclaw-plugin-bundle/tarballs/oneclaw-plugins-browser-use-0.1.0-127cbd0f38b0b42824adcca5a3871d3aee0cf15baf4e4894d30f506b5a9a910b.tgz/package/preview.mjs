import { resolveBrowserShareCredential } from './share.mjs';

// Read-only capture is separate from agent admission: it never focuses a tab,
// starts Chromium, changes a control lease, or writes screenshots to disk.
export function createTaskPreview({ env = process.env, fetchImpl = fetch, credentialScope = globalThis } = {}) {
  return async (targetId) => {
    const port = Number(env.PORT || 8080);
    if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('Preview is unavailable');
    const credential = resolveBrowserShareCredential(env, credentialScope);
    const response = await fetchImpl(`http://127.0.0.1:${port}/browser/internal/preview`, {
      method: 'POST', redirect: 'error',
      headers: { Authorization: credential.authorizationHeader(), 'Content-Type': 'application/json' },
      body: JSON.stringify({ targetId }), signal: AbortSignal.timeout(5000),
    });
    const result = await response.json();
    if (!response.ok || !/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(result.image || '') || result.image.length > 700000) throw new Error('Preview is unavailable');
    return result.image;
  };
}

export function registerTaskPreview(api, work, capture, { now = Date.now } = {}) {
  const cache = new Map();
  let inFlight = 0;
  api.registerGatewayMethod('browseruse.preview', async ({ params, respond }) => {
    try {
      const task = work.status(params?.sessionKey);
      if (!params?.sessionKey || !task?.runId || task.phase === 'expired' || !Array.isArray(params.runIds) || params.runIds.length > 16 || !params.runIds.includes(task.runId)) throw new Error('No matching browser task');
      const key = `${task.sessionKey}:${task.runId}:${task.targetId}`;
      let entry = cache.get(key);
      if (!entry || now() - entry.at >= 900) {
        if (inFlight >= 2) throw new Error('Preview is busy');
        inFlight++;
        entry = { at: now(), promise: Promise.resolve().then(() => capture(task.targetId)).finally(() => { inFlight--; }) };
        cache.set(key, entry);
        if (cache.size > 128) cache.delete(cache.keys().next().value);
        entry.promise.catch(() => { if (cache.get(key) === entry) cache.delete(key); });
      }
      const image = await entry.promise;
      const current = work.status(task.sessionKey);
      if (current?.targetId !== task.targetId || current?.runId !== task.runId || current.phase === 'expired') throw new Error('Browser task changed');
      respond(true, { sessionKey: task.sessionKey, runId: task.runId, targetId: task.targetId, image, capturedAt: entry.at });
    } catch { respond(false, undefined, { code: 'UNAVAILABLE', message: 'Browser task preview is temporarily unavailable' }); }
  }, { scope: 'operator.read' });
}
