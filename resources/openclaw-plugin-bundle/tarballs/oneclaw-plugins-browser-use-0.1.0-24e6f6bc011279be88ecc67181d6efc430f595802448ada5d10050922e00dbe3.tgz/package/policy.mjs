export const BROWSER_USE_GUIDANCE = 'Browser Use provides headed Chromium on Xvfb :99, visible to the user. Use native browser with profile="openclaw", target="host" and load the browser-use skill from the exact supplied location, never guess a skill path. Reuse this task tab where possible and retain its targetId; navigation, snapshots and actions must identify their target. After switching to a new result tab, get a full snapshot BEFORE act/evaluate; tabs is not a snapshot. Prefer explicitly named accessible cells that already pair item, column label and value. Do not replace those values with guesses from DOM cell offsets. Use evaluate only if a full snapshot lacks the required values. If a query opens a result tab, use it rather than opening another; after verifying results, close only the obsolete entry tab created by this task when it contains no unsaved work. Keep user and other-task tabs. Verify actual URL after navigation; a failed navigation is not evidence of a redirect. Do not restart browsers or change DISPLAY/config/headless mode to work around failures. Share via browser_use action="share" and send the stable URL verbatim, never Runtime credentials. When human control is pending/active call browser_use action="wait"; it waits for explicit handback and lets this task continue. Do not end the task or bypass through exec/MCP/CLI/CDP. After wait, list tabs and get a fresh snapshot of the task target before actions. Public information lookup may use web_search/web_fetch.';

export function managedBrowserParams(event) {
  if (event.toolName !== 'browser') return undefined;
  const params = event.params || {};
  if (params.action === 'stop') throw new Error('Browser Use: Chromium is shared by conversations. Close only this task tab; idle suspension is managed by the Runtime.');
  if (params.headless !== undefined && params.headless !== false) throw new Error('Browser Use requires headed Chromium on DISPLAY=:99; headless startup is not allowed. Use browser start with profile="openclaw", target="host".');
  if ((params.profile !== undefined && params.profile !== 'openclaw') || (params.target !== undefined && params.target !== 'host') || params.node) {
    throw new Error('Browser Use operates the visible Runtime browser only: profile="openclaw", target="host". Other profiles/nodes/sandbox do not share the preview or handoff.');
  }
  if (params.action === 'start' && ['args', 'extraArgs', 'executablePath'].some((key) => params[key] !== undefined)) {
    throw new Error('Browser Use manages Chromium launch arguments. Do not supply custom launch arguments; inspect browser status/doctor if startup fails.');
  }
  let request = params.request;
  // The native fill API accepts fields[], while models sometimes use the
  // single-field ref/text shape from type. Preserve the exact supplied value.
  if (params.action === 'act' && request?.kind === 'fill' && request.fields === undefined && typeof request.ref === 'string' && typeof request.text === 'string') {
    const { ref, text, ...rest } = request;
    request = { ...rest, fields: [{ ref, value: text }] };
  }
  return { ...params, ...(request ? { request } : {}), profile: 'openclaw', target: 'host' };
}
