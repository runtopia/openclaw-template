const INSTANCE_CREDENTIAL_KEY = Symbol.for('@oneclaw-plugins/instance-credential');

export function resolveBrowserShareCredential(env, scope = globalThis) {
  const existing = scope[INSTANCE_CREDENTIAL_KEY];
  if (existing && typeof existing.authorizationHeader === 'function') return existing;
  const secret = env.ONECLAW_INSTANCE_SECRET?.trim();
  if (!secret) throw new Error('Browser Use Runtime credential is unavailable; check the platform credential configuration');
  const credential = Object.freeze({ authorizationHeader: () => `Bearer ${secret}` });
  scope[INSTANCE_CREDENTIAL_KEY] = credential;
  delete env.ONECLAW_INSTANCE_SECRET;
  return credential;
}

const ID = /^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/;

function origin(value) {
  const url = new URL(value);
  if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password || url.search || url.hash || url.pathname !== '/') throw new Error('Browser Use web URL must be a configured HTTP(S) origin');
  return url.origin;
}

export function createBrowserShareTool(context = {}, { env = process.env, fetchImpl = fetch, credentialScope = globalThis, control } = {}) {
  return {
    name: 'browser_use',
    label: 'Browser Use',
    description: 'Use action=share to get the browser entry URL. Use action=wait when human control is pending/active: this waits until explicit handback, keeping the task alive. After wait, get fresh tabs/snapshot before continuing. Neither action sends a message or grants control.',
    parameters: { type: 'object', additionalProperties: false, properties: { action: { type: 'string', enum: ['share', 'wait'] } }, required: ['action'] },
    async execute(_callId, args, signal) {
      if (!['share', 'wait'].includes(args?.action) || Object.keys(args).some((key) => key !== 'action')) throw new Error('Use browser_use with only action="share" or action="wait"; Runtime identity cannot be supplied by the model');
      const trustedSession = typeof context.sessionKey === 'string' && context.sessionKey.length > 0;
      const channelSession = trustedSession && /:oneclaw:direct:session_[A-Za-z0-9_-]+$/.test(context.sessionKey);
      if (!trustedSession || (!channelSession && context.senderIsOwner !== true)) throw new Error('Browser Use share requires a trusted OneClaw session or authenticated owner session');
      if (args.action === 'wait') {
        if (!control) throw new Error('Browser Use control service is unavailable');
        control.work?.waiting(context);
        const state = await control.waitForAI(signal, 900000, context.sessionKey);
        return { content: [{ type: 'text', text: 'The user returned browser control. List tabs and obtain a fresh snapshot of the task target before continuing.' }], details: { kind: 'browser-use-handback', epoch: state.epoch } };
      }
      const instance = env.ONECLAW_RUNTIME_ID?.trim() || env.ONECLAW_INSTANCE_ID?.trim();
      if (!instance) throw new Error('Browser Use Runtime identity is unavailable; check ONECLAW_RUNTIME_ID or ONECLAW_INSTANCE_ID');
      const credential = resolveBrowserShareCredential(env, credentialScope);
      const api = new URL(env.ONECLAW_API_URL || 'https://www.oneclaw.net/api/v1');
      if (!['https:', 'http:'].includes(api.protocol) || api.username || api.password || api.search || api.hash) throw new Error('Invalid Runtime API configuration');
      api.pathname = `${api.pathname.replace(/\/$/, '') || '/api/v1'}/runtime/personality`;
      let response;
      try {
        response = await fetchImpl(api, {
          method: 'GET', redirect: 'error',
          headers: { Authorization: credential.authorizationHeader(), 'X-OneClaw-Instance-ID': instance, Accept: 'application/json' },
          signal: signal ? AbortSignal.any([signal, AbortSignal.timeout(8000)]) : AbortSignal.timeout(8000),
        });
      } catch { throw new Error('Browser Use could not verify the current Runtime with the platform'); }
      if (!response.ok) throw new Error(`Browser Use identity lookup failed (HTTP ${response.status})`);
      let identity;
      try { identity = await response.json(); } catch { throw new Error('Browser Use received an invalid platform identity response'); }
      const workspaceId = identity?.workspace?.id;
      if (identity?.instance_id !== instance || typeof workspaceId !== 'string' || !ID.test(workspaceId)) throw new Error('Browser Use identity does not match this Runtime');
      const configuredWeb = env.ONECLAW_BROWSER_USE_WEB_URL?.trim() || identity.app_url || env.NEXT_PUBLIC_APP_URL?.trim();
      const defaultWeb = ['www.oneclaw.net', 'oneclaw.net', 'api.oneclaw.net'].includes(api.hostname) ? 'https://www.oneclaw.net' : undefined;
      if (!configuredWeb && !defaultWeb) throw new Error('Browser Use Web address is unavailable; update the platform API to expose its existing app_url configuration');
      const webOrigin = origin(configuredWeb || defaultWeb);
      const url = `${webOrigin}/browser-use/${workspaceId}`;
      return {
        content: [{ type: 'text', text: url }],
        details: { kind: 'browser-use-link', url, delivery: 'not_sent' },
      };
    },
  };
}
