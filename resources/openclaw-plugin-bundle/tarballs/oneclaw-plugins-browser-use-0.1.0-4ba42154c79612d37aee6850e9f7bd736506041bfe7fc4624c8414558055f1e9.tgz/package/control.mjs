import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

export const MANAGED_TOOLS = new Set(['browser', 'exec', 'process', 'gateway', 'nodes']);
// Opening a new tab cannot reuse stale element refs, and is necessary when
// there are no existing task tabs available to snapshot after handback.
const REOBSERVE_ACTIONS = new Set(['status', 'doctor', 'start', 'tabs', 'open', 'focus', 'snapshot', 'screenshot']);
const hash = (value) => crypto.createHash('sha256').update(value).digest('hex');

// One authority per Runtime. Unknown/crashed in-flight operations never expire
// into permission to type; recovery must be an explicit administrative action.
export function createControl({ file, now = Date.now, browserQueueTimeoutMs = 60000 }) {
  let data = { mode: 'ai', epoch: 0, ownerHash: null, active: {} };
  const observed = new Map();
  const waiters = new Map();
  const browserQueue = new Map();
  if (fs.existsSync(file)) {
    try {
      const saved = JSON.parse(fs.readFileSync(file, 'utf8'));
      if (!['ai', 'waiting', 'human', 'paused'].includes(saved.mode) || !Number.isInteger(saved.epoch) || !saved.active || typeof saved.active !== 'object') throw new Error('Invalid control state');
      data = saved;
      if (data.mode !== 'ai' || Object.keys(data.active).length) data.mode = 'paused';
    } catch { data = { mode: 'paused', epoch: 1, ownerHash: null, active: { unknown: { tool: 'unknown' } } }; }
  }
  function persist() {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const temp = `${file}.${process.pid}.tmp`;
    fs.writeFileSync(temp, JSON.stringify(data), { mode: 0o600 });
    fs.renameSync(temp, file);
  }
  persist();
  function status(sessionKey) {
    return { mode: data.mode, epoch: data.epoch, inFlight: Object.keys(data.active).length, tools: [...new Set(Object.values(data.active).map((x) => x.tool))], waitingForAI: waiters.size, queuedBrowser: browserQueue.size, ...(sessionKey ? { queuePosition: [...browserQueue.values()].findIndex(call => call.session === sessionKey) + 1 } : {}) };
  }
  function requireOwner(token) {
    if (typeof token !== 'string' || !data.ownerHash || hash(token) !== data.ownerHash) throw new Error('Browser control belongs to another connection');
  }
  function keyOf(event, context = {}) {
    const call = event.toolCallId || context.toolCallId;
    if (!call) throw new Error('Browser Use requires a stable tool call id');
    return JSON.stringify([event.runId || context.runId || '', context.sessionKey || context.sessionId || '', call]);
  }
  function begin(event, context = {}, lifecycleClose = false) {
    if (!MANAGED_TOOLS.has(event.toolName)) return;
    const drainingPoll = data.mode === 'waiting' && event.toolName === 'process' && event.params?.action === 'poll' && Object.values(data.active).some((call) => call.background === event.params?.sessionId);
    if (data.mode === 'paused') throw new Error('Browser Use: AI control is paused after an interrupted operation or connection. This does not mean a human is currently operating the browser. Unfinished operations must be checked by the Runtime operator before recovery; do not bypass through CDP/exec or tell the user to hand back a human session that has not been confirmed.');
    if (data.mode !== 'ai' && !drainingPoll) throw new Error('Browser Use: human control is pending or active. Call browser_use with action="wait" to wait for handback, then get fresh tabs/snapshot. Do not retry or bypass through CDP/exec.');
    const session = context.sessionKey || context.sessionId || '';
    const action = event.params?.action;
    const targetId = event.params?.targetId || event.params?.request?.targetId || '';
    if (event.toolName === 'browser' && Object.values(data.active).some((call) => call.tool === 'browser')) throw new Error('Browser Use: another browser operation is still running. Wait for it to finish before using this task tab.');
    if (event.toolName === 'browser' && !(lifecycleClose && action === 'close') && data.epoch > 0 && !REOBSERVE_ACTIONS.has(action) && observed.get(JSON.stringify([session, targetId])) !== data.epoch) {
      throw new Error(`Browser Use: this task tab requires a new browser snapshot before actions. Call browser action="snapshot" with targetId=${JSON.stringify(targetId)} first; action="tabs" does not observe the page. Previous refs may be stale.`);
    }
    const key = keyOf(event, context);
    if (data.active[key]) throw new Error('Duplicate managed tool execution');
    data.active[key] = { tool: event.toolName, action, targetId, processSession: event.params?.sessionId, session, epoch: data.epoch, at: now() };
    try { persist(); } catch (err) { data.mode = 'paused'; throw err; }
  }
  // Brief browser contention is handled here, rather than asking the model to
  // retry. A queued call has no execution lease until it actually starts.
  // Timeout/cancellation never remove the lease of the preceding operation.
  function admit(event, context = {}, signal = context?.signal) {
    if (event.toolName !== 'browser' || data.mode !== 'ai' || !Object.values(data.active).some(call => call.tool === 'browser')) {
      if (signal?.aborted) throw signal.reason || new Error('Browser operation cancelled');
      begin(event, context);
      return;
    }
    const id = keyOf(event, context);
    if (browserQueue.has(id) || data.active[id]) throw new Error('Duplicate managed tool execution');
    if (signal?.aborted) throw signal.reason || new Error('Browser operation cancelled');
    return new Promise((resolve, reject) => {
      const cleanup = () => { clearTimeout(timer); browserQueue.delete(id); signal?.removeEventListener('abort', abort); };
      const fail = (error) => { cleanup(); reject(error); };
      const abort = () => fail(signal.reason || new Error('Browser operation cancelled'));
      const timer = setTimeout(() => fail(new Error('Browser Use: the preceding browser operation has not completed. Do not retry in a loop or bypass through exec/CDP; report the blocked operation.')), browserQueueTimeoutMs);
      browserQueue.set(id, { session: context.sessionKey || context.sessionId || '', runId: event.runId || context.runId,
        fail, start: () => { cleanup(); try { begin(event, context); resolve(); } catch (error) { reject(error); } } });
      signal?.addEventListener('abort', abort, { once: true });
    });
  }
  function drainBrowserQueue() {
    if (data.mode !== 'ai') {
      for (const pending of [...browserQueue.values()]) pending.fail(new Error(data.mode === 'paused'
        ? 'Browser Use: AI control is paused. Do not bypass through exec/CDP.'
        : 'Browser Use: human control is pending or active. Call browser_use with action="wait" to wait for handback.'));
      return;
    }
    while (browserQueue.size && !Object.values(data.active).some(call => call.tool === 'browser')) browserQueue.values().next().value.start();
  }
  function cancelQueued(context = {}) {
    const session = context.sessionKey || context.sessionId || '';
    for (const pending of [...browserQueue.values()]) if (pending.session === session && (!context.runId || pending.runId === context.runId)) pending.fail(new Error('Browser operation cancelled: agent run ended'));
  }
  function end(event, context = {}) {
    if (!MANAGED_TOOLS.has(event.toolName)) return;
    let key;
    try { key = keyOf(event, context); } catch { return; }
    const call = data.active[key];
    if (!call) return;
    if (call.uncertain) return; // A blocked tool hook cannot settle an uncertain native focus/stop.
    const details = event.result?.details;
    if (call.tool === 'exec' && details?.status === 'running') {
      call.background = details.sessionId || 'unknown';
      persist();
      return;
    }
    delete data.active[key];
    if (call.tool === 'process' && call.action === 'poll' && ['completed', 'failed'].includes(details?.status) && details.sessionId === call.processSession) {
      for (const [id, running] of Object.entries(data.active)) {
        if (running.background === details.sessionId && running.session === call.session) delete data.active[id];
      }
    }
    if (call.tool === 'browser' && call.action === 'snapshot' && !event.error && !event.result?.isError && call.epoch === data.epoch) observed.set(JSON.stringify([call.session, call.targetId || '']), data.epoch);
    persist();
    drainBrowserQueue();
  }
  function uncertain(event, context = {}) {
    const call = data.active[keyOf(event, context)];
    if (!call) return;
    call.uncertain = true;
    data.mode = 'paused';
    persist();
    drainBrowserQueue();
  }
  function owns(event, context = {}) {
    const call = data.active[keyOf(event, context)];
    return Boolean(call && call.tool === event.toolName && call.action === event.params?.action);
  }
  function command(params) {
    const { action, token } = params || {};
    if (action === 'status') return status();
    if (action === 'validate-focus' || action === 'validate-close') {
      const call = data.active[JSON.stringify([params.runId || '', params.sessionKey || '', params.toolCallId || ''])];
      if (!['ai', 'waiting'].includes(data.mode) || !call || call.tool !== 'browser' || call.targetId !== params.targetId
          || !(action === 'validate-close' ? ['close'] : ['focus', 'snapshot', 'screenshot', 'navigate', 'act']).includes(call.action) || call.uncertain) throw new Error('No admitted task operation owns this browser tab');
      return { ok: true };
    }
    if (action === 'admin-starts') {
      const starts = [];
      for (const [key, call] of Object.entries(data.active)) {
        if (call.tool !== 'browser' || call.action !== 'start' || call.session !== 'wrapper') continue;
        try {
          const [run, session, callId] = JSON.parse(key);
          if (run === 'wrapper' && session === 'wrapper' && typeof callId === 'string') starts.push({ callId });
        } catch { /* Unknown records must stay blocked. */ }
      }
      return { starts };
    }
    if (action === 'admin-begin' || action === 'admin-end') {
      if (typeof params.callId !== 'string' || params.callId.length > 100) throw new Error('Invalid call id');
      const operation = params.operation || 'start';
      if (!['start', 'stop'].includes(operation)) throw new Error('Invalid wrapper operation');
      const event = { toolName: 'browser', params: { action: operation }, toolCallId: params.callId, runId: 'wrapper' };
      if (action === 'admin-begin') begin(event, { sessionKey: 'wrapper' });
      else end(event, { sessionKey: 'wrapper' });
      return status();
    }
    if (action === 'request') {
      if (data.mode !== 'ai') throw new Error('Browser is already reserved; recover or release the existing session');
      if (typeof token !== 'string' || token.length < 32) throw new Error('Invalid controller token');
      data.mode = 'waiting'; data.ownerHash = hash(token); persist();
    } else if (action === 'grant') {
      requireOwner(token);
      if (data.mode !== 'waiting' || Object.keys(data.active).length) throw new Error('Waiting for in-flight operations to finish');
      data.mode = 'human'; persist();
    } else if (action === 'resume') {
      requireOwner(token);
      if (data.mode !== 'paused' || Object.keys(data.active).length) throw new Error('Only a drained, paused browser can resume human control');
      data.mode = 'human'; persist();
    } else if (action === 'pause') {
      requireOwner(token); data.mode = 'paused'; persist();
    } else if (action === 'release') {
      requireOwner(token);
      if (Object.keys(data.active).length) throw new Error('In-flight operations remain; refusing to release control');
      data.mode = 'ai'; data.ownerHash = null; data.epoch++; persist();
    } else if (action === 'recover') {
      // Caller must stop the writable VNC process first. Recovery does not
      // discard unknown leases: a stuck tool requires operator investigation.
      if (data.mode !== 'paused' || Object.keys(data.active).length) throw new Error('Only a paused, drained browser can be recovered');
      data.mode = 'ai'; data.ownerHash = null; data.epoch++; persist();
    } else throw new Error('Unknown Browser Use command');
    const resumedWaitingTasks = data.mode === 'ai' ? waiters.size : 0;
    drainBrowserQueue();
    if (data.mode === 'ai') for (const resolve of [...waiters.keys()]) resolve();
    return { ...status(), ...(['release', 'recover'].includes(action) ? { resumedWaitingTasks } : {}) };
  }
  function waitForAI(signal, timeoutMs = 900000, sessionKey = '') {
    if (signal?.aborted) return Promise.reject(signal.reason || new Error('Browser wait cancelled'));
    if (data.mode === 'ai') return Promise.resolve(status());
    return new Promise((resolve, reject) => {
      const cleanup = () => { clearTimeout(timer); waiters.delete(done); signal?.removeEventListener('abort', abort); };
      const done = () => { cleanup(); resolve(status()); };
      const abort = () => { cleanup(); reject(signal.reason || new Error('Browser wait cancelled')); };
      const timer = setTimeout(() => { cleanup(); reject(new Error('Browser Use: still waiting for the user. Do not take control automatically.')); }, timeoutMs);
      waiters.set(done, sessionKey);
      signal?.addEventListener('abort', abort, { once: true });
    });
  }
  const waiterCount = (sessionKey) => [...waiters.values()].filter((key) => key === sessionKey).length;
  return { activeFor: (session, target) => Object.values(data.active).filter(call => call.session === session || (target && call.targetId === target)).length, requireFreshSnapshots: () => { data.epoch++; persist(); }, status, begin, admit, end, uncertain, owns, command, waitForAI, waiterCount, cancelQueued };
}


// Plugin registration can repeat during tools discovery or an in-process
// Gateway reload. Reuse one authority rather than re-reading live state as if
// the process had crashed, or creating multiple writers for the same file.
export function processControl(options, scope = globalThis) {
  const key = Symbol.for('@oneclaw-plugins/browser-use/control-authorities');
  const controls = scope[key] ??= new Map();
  const file = path.resolve(options.file);
  if (!controls.has(file)) controls.set(file, createControl({ ...options, file }));
  return controls.get(file);
}
