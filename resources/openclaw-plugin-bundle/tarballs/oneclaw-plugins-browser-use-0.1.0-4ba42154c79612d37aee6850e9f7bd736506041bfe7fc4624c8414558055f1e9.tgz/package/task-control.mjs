import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
const hash = (value) => crypto.createHash("sha256").update(value).digest("hex");

/** Page-scoped control. Native desktop control remains a separate global lease. */
export function createTaskControl({ work, control, file, now = Date.now }) {
  const leases = new Map(),
    waiters = new Map();
  if (file && fs.existsSync(file)) {
    for (const lease of JSON.parse(fs.readFileSync(file, "utf8")).leases || [])
      leases.set(lease.browserTaskId, { ...lease, mode: "paused" });
  }
  const persist = () => {
    if (!file) return;
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const temp = `${file}.${process.pid}.tmp`;
    fs.writeFileSync(temp, JSON.stringify({ leases: [...leases.values()] }), {
      mode: 0o600,
    });
    fs.renameSync(temp, file);
  };
  const active = (task) =>
    control.activeFor?.(task.sessionKey, task.targetId) || 0;
  const mine = (lease, token) =>
    typeof token === "string" &&
    token.length >= 32 &&
    lease?.ownerHash === hash(token);
  function status(task, token) {
    const lease = leases.get(task.browserTaskId);
    if (lease && lease.mode === "human" && now() - lease.seen > 45000) {
      lease.mode = "paused";
      persist();
    }
    if (lease && lease.mode === "waiting" && !active(task)) {
      lease.mode =
        task.resourceState === "live" && task.generation === lease.generation
          ? "human"
          : "paused";
      lease.targetId = task.targetId;
      lease.targets = work.targets(task.sessionKey, {
        browserTaskId: task.browserTaskId,
      });
      persist();
    }
    if (lease && mine(lease, token)) lease.seen = now();
    return {
      ...control.status(task.sessionKey),
      schemaVersion: 1,
      scoped: true,
      browser: task,
      mode: lease?.mode || "ai",
      mine: mine(lease, token),
      epoch: lease?.epoch || control.status().epoch + 1,
      inFlight: (lease?.pending ? 1 : 0) + active(task),
      available: true,
    };
  }
  function check(event, context) {
    const session = context?.sessionKey || context?.sessionId;
    const target = event.params?.targetId || event.params?.request?.targetId;
    const lease = [...leases.values()].find(
      (l) => l.sessionKey === session || l.targets.includes(target),
    );
    if (event.toolName === "browser") {
      if (
        lease ||
        (leases.size &&
          ["start", "stop", "resize"].includes(event.params?.action))
      )
        throw new Error(
          'Browser Use: this task is under human control. Call browser_use action="wait"; other conversations may continue on their own pages.',
        );
    } else if (
      leases.size &&
      ["exec", "process", "gateway", "nodes"].includes(event.toolName)
    ) {
      throw new Error(
        "Browser Use: manual task control is active; shared system tools are paused. Use another task’s scoped browser operations or wait for handback.",
      );
    }
  }
  function command(params, task) {
    const { action, token } = params;
    let lease = leases.get(task.browserTaskId);
    if (action === "status") return status(task, token);
    if (action === "request") {
      if (
        control.status().mode !== "ai" ||
        task.resourceState !== "live" ||
        lease ||
        typeof token !== "string" ||
        token.length < 32
      )
        throw new Error("Task control is unavailable");
      lease = {
        browserTaskId: task.browserTaskId,
        generation: task.generation,
        sessionKey: task.sessionKey,
        targets: work.targets(task.sessionKey, {
          browserTaskId: task.browserTaskId,
        }),
        targetId: task.targetId,
        mode: active(task) ? "waiting" : "human",
        ownerHash: hash(token),
        seen: now(),
        epoch: control.status().epoch + 1,
        pending: null,
      };
      leases.set(task.browserTaskId, lease);
      work.retainTask?.(task.sessionKey, task.browserTaskId);
      persist();
      return status(task, token);
    }
    if (action === "recover") {
      if (!lease || lease.mode !== "paused" || lease.pending || active(task))
        throw new Error("Only a drained paused task can recover");
      leases.delete(task.browserTaskId);
      persist();
      control.requireFreshSnapshots?.();
      const resumedWaitingTasks = waiters.get(task.sessionKey)?.size || 0;
      for (const done of [...(waiters.get(task.sessionKey) || [])]) done();
      return { ...status(task, token), resumedWaitingTasks };
    }
    if (!mine(lease, token))
      throw new Error("This connection does not own task control");
    if (action === "pause") {
      lease.mode = "paused";
      persist();
      return status(task, token);
    }
    if (action === "resume") {
      if (
        lease.pending ||
        active(task) ||
        task.resourceState !== "live" ||
        lease.generation !== task.generation ||
        control.status().mode !== "ai"
      )
        throw new Error("Unfinished operation or expired task");
      lease.mode = "human";
      lease.seen = now();
      persist();
      return status(task, token);
    }
    if (action === "release") {
      if (lease.pending || active(task))
        throw new Error("Unfinished input; keep task paused");
      leases.delete(task.browserTaskId);
      persist();
      control.requireFreshSnapshots?.();
      const resumedWaitingTasks = waiters.get(task.sessionKey)?.size || 0;
      for (const done of [...(waiters.get(task.sessionKey) || [])]) done();
      return {
        ...status(task, token),
        epoch: lease.epoch + 1,
        resumedWaitingTasks,
      };
    }
    if (action === "select") {
      if (lease.mode !== "human" || lease.pending || active(task))
        throw new Error("Pause input before selecting a page");
      const selected = work.selectTarget(
        task.sessionKey,
        { browserTaskId: task.browserTaskId },
        params.targetId,
      );
      lease.targetId = selected.targetId;
      persist();
      return status(selected, token);
    }
    if (action === "input-begin") {
      if (
        params.expectedTargetId !== task.targetId ||
        params.generation !== task.generation
      )
        throw new Error("Task frame changed; refresh before input");
      status(task, token);
      if (
        control.status().mode !== "ai" ||
        lease.mode !== "human" ||
        lease.pending ||
        active(task) ||
        task.resourceState !== "live" ||
        task.generation !== lease.generation ||
        task.targetId !== lease.targetId
      )
        throw new Error("Task input is unavailable");
      if (typeof params.callId !== "string" || params.callId.length > 100)
        throw new Error("Invalid input lease");
      lease.pending = params.callId;
      persist();
      return { targetId: task.targetId, generation: task.generation };
    }
    if (action === "input-end") {
      if (params.callId !== lease.pending)
        throw new Error("Input lease mismatch");
      if (params.uncertain) lease.mode = "paused";
      else {
        lease.pending = null;
        work.adoptPages?.(
          task.sessionKey,
          { browserTaskId: task.browserTaskId },
          params.pages,
        );
        const selected = work.status?.(task.sessionKey, {
          browserTaskId: task.browserTaskId,
        });
        if (selected) {
          lease.targetId = selected.targetId;
          lease.targets = work.targets(task.sessionKey, {
            browserTaskId: task.browserTaskId,
          });
        }
      }
      persist();
      return status(task, token);
    }
    throw new Error("Unknown task control action");
  }
  function wait(sessionKey, signal) {
    if (![...leases.values()].some((l) => l.sessionKey === sessionKey))
      return Promise.resolve();
    return new Promise((resolve, reject) => {
      const set = waiters.get(sessionKey) || new Set();
      waiters.set(sessionKey, set);
      const cleanup = () => {
        clearTimeout(timer);
        set.delete(done);
        if (!set.size) waiters.delete(sessionKey);
        signal?.removeEventListener("abort", abort);
      };
      const done = () => {
        cleanup();
        resolve();
      };
      const abort = () => {
        cleanup();
        reject(new Error("Browser task wait cancelled"));
      };
      const timer = setTimeout(() => {
        cleanup();
        reject(new Error("Still waiting for task handback"));
      }, 900000);
      set.add(done);
      signal?.addEventListener("abort", abort, { once: true });
      if (signal?.aborted) abort();
    });
  }
  return {
    modeFor: (session) =>
      [...leases.values()].find((l) => l.sessionKey === session)?.mode,
    check,
    command,
    wait,
    has: () => leases.size > 0,
  };
}
