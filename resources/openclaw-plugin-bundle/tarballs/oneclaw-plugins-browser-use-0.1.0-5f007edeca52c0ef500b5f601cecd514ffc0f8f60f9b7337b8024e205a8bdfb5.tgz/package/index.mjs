import os from "node:os";
import { createTaskControl } from "./task-control.mjs";
import { resolveBrowserShareCredential } from "./share.mjs";
import { createBrowserShareTool } from "./share.mjs";
import path from "node:path";
import { processControl, MANAGED_TOOLS } from "./control.mjs";
import { BROWSER_USE_GUIDANCE, managedBrowserParams } from "./policy.mjs";
import { createBrowserWork } from "./work.mjs";
import { createTaskFocus } from "./focus.mjs";
import { createTaskPreview, registerTaskPreview } from "./preview.mjs";
import crypto from "node:crypto";
import { fileURLToPath } from "node:url";

export function registerBrowserUse(
  api,
  control,
  {
    focus = createTaskFocus(),
    close = createTaskFocus({ operation: "close" }),
    preview = createTaskPreview(),
    workFile,
    idleMs = 1800000,
  } = {},
) {
  const work = (control.work ??= createBrowserWork({ file: workFile }));
  const taskControl = (control.taskControl ??= createTaskControl({
    work,
    control,
    file: workFile ? workFile + ".control" : undefined,
  }));
  registerTaskPreview(api, work, preview);
  api.registerGatewayMethod(
    "browseruse.task-authority",
    async ({ params, respond }) => {
      try {
        const task = params?.nativeSessionId
          ? work.nativeStatus(params.nativeSessionId, params)
          : work.status(params?.sessionKey, params);
        if (!task || !params.browserTaskId) throw new Error("No matching task");
        if (params.action === "status") work.viewed(task.browserTaskId);
        respond(true, taskControl.command(params, task));
      } catch (error) {
        respond(false, undefined, {
          code: "UNAVAILABLE",
          message: error.message,
        });
      }
    },
    { scope: "operator.admin" },
  );
  api.registerGatewayMethod(
    "browseruse.task",
    async ({ params, respond }) => {
      try {
        const task = work.status(params?.sessionKey, params);
        if (!task || !params.browserTaskId) throw new Error("No matching task");
        const credential = resolveBrowserShareCredential(
          process.env,
          globalThis,
        );
        const response = await fetch(
          `http://127.0.0.1:${Number(process.env.PORT || 8080)}/browser/internal/task`,
          {
            method: "POST",
            redirect: "error",
            headers: {
              Authorization: credential.authorizationHeader(),
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              ...params,
              browserTaskId: task.browserTaskId,
            }),
            signal: AbortSignal.timeout(10000),
          },
        );
        if (!response.ok) throw new Error("Task control unavailable");
        respond(true, await response.json());
      } catch (error) {
        respond(false, undefined, {
          code: "UNAVAILABLE",
          message: error.message,
        });
      }
    },
    { scope: "operator.admin" },
  );
  api.on(
    "before_tool_call",
    (event, context) => {
      if (
        MANAGED_TOOLS.has(event.toolName) &&
        !(event.runId || context?.runId)
      ) {
        return {
          block: true,
          blockReason:
            "Browser Use requires a managed agent run with completion hooks; unscoped tools.invoke is not supported for browser/exec control.",
        };
      }
      try {
        const managed = managedBrowserParams(event);
        const params = managed ? work.prepare(managed, context) : undefined;
        const prepared = params ? { ...event, params } : event;
        taskControl.check(prepared, context);
        const blocked = (err) => {
          if (["human", "waiting"].includes(control.status().mode))
            work.waiting(context);
          return { block: true, blockReason: err.message };
        };
        const proceed = () => {
          try {
            taskControl.check(prepared, context);
          } catch (error) {
            control.end(prepared, context);
            throw error;
          }
          work.noteCall(prepared, context);
          if (
            params?.targetId &&
            ["snapshot", "screenshot", "navigate", "act"].includes(
              params.action,
            )
          ) {
            return focus(prepared, context)
              .then(() => ({ params }))
              .catch((error) => {
                if (error.browserOperationUncertain)
                  control.uncertain(prepared, context);
                else
                  control.end(
                    { ...prepared, error: "Task tab focus failed" },
                    context,
                  );
                return {
                  block: true,
                  blockReason: error.browserOperationUncertain
                    ? "Browser Use: task focus completion is unknown. AI control is paused for Runtime recovery; do not bypass this state."
                    : "Browser Use: task tab could not be focused. List tabs and select a valid targetId before continuing.",
                };
              });
          }
          return params ? { params } : undefined;
        };
        const admission = control.admit
          ? control.admit(prepared, context)
          : control.begin(prepared, context);
        return admission ? admission.then(proceed).catch(blocked) : proceed();
      } catch (err) {
        if (["human", "waiting"].includes(control.status().mode))
          work.waiting(context);
        return { block: true, blockReason: err.message };
      }
    },
    { priority: -100000 },
  );
  api.on("after_tool_call", (event, context) => {
    control.end(event, context);
    work.complete(event, context, control.status().mode);
  });
  api.on("agent_end", async (event, context) => {
    control.cancelQueued?.(context);
    const sessionKey = context?.sessionKey || context?.sessionId;
    const task = work.status(sessionKey);
    if (
      task?.resourceState === "live" &&
      (!context?.runId || task.previewRunId === context.runId)
    ) {
      try {
        const image = await preview(task.targetId);
        const latest = work.status(sessionKey, {
          browserTaskId: task.browserTaskId,
        });
        if (latest?.previewRunId === task.previewRunId)
          work.saveFrame(
            sessionKey,
            { browserTaskId: task.browserTaskId },
            {
              browserTaskId: task.browserTaskId,
              generation: task.generation,
              sessionKey,
              runId: task.previewRunId,
              targetId: task.targetId,
              image,
              capturedAt: Date.now(),
              displayUrl: task.displayUrl,
            },
          );
      } catch {
        /* Capture failure must not prevent completion or fabricate an image. */
      }
    }
    work.finish(event, context);
  });
  api.on("before_prompt_build", (_event, context) => {
    work.touch(context);
    const { mode: globalMode, epoch, inFlight } = control.status();
    const mode =
      globalMode !== "ai" ? globalMode : taskControl.modeFor(context?.sessionKey) || globalMode;
    return {
      appendSystemContext: `${BROWSER_USE_GUIDANCE}\nBrowser Use skill location: ${fileURLToPath(new URL("./skills/browser-use/SKILL.md", import.meta.url))}\nCurrent Browser Use control state: ${JSON.stringify({ mode, epoch, inFlight })}. This live state supersedes earlier chat statements about control. When mode is ai, proceed with the browser task. When mode is paused, explain that AI control is paused; do not describe it as an active human session. Only waiting/human means a human takeover is pending/active.`,
    };
  });
  api.registerGatewayMethod(
    "browseruse.control",
    async ({ params, respond }) => {
      try {
        if (params?.nativeSessionId !== undefined) {
          const task = work.nativeStatus(params.nativeSessionId, params);
          if (
            !task ||
            !["status", "view", "retain", "unretain", "close-task"].includes(
              params.action,
            )
          )
            throw new Error("No matching native browser task");
          params = { ...params, sessionKey: task.sessionKey };
        }
        if (params?.action === "close-task") {
          const task = work.status(params.sessionKey, params),
            state = control.status();
          if (
            !(params.browserTaskId || params.toolCallId) ||
            !task ||
            task.resourceState !== "live" ||
            !["completed", "failed", "cancelled"].includes(task.phase) ||
            state.mode !== "ai" ||
            state.inFlight
          )
            throw new Error(
              "Finish the task and return control before closing its pages",
            );
          taskControl.check(
            {
              toolName: "browser",
              params: { action: "close", targetId: task.targetId },
            },
            { sessionKey: task.sessionKey },
          );
          const selector = { browserTaskId: task.browserTaskId };
          const image = await preview(task.targetId);
          work.saveFrame(task.sessionKey, selector, {
            ...task,
            runId: task.previewRunId,
            image,
            capturedAt: Date.now(),
          });
          for (const targetId of work.targets(task.sessionKey, selector)) {
            const event = {
              toolName: "browser",
              runId: "viewer",
              toolCallId: crypto.randomUUID(),
              params: { action: "close", targetId },
            };
            const context = { sessionKey: task.sessionKey };
            taskControl.check(event, context);
            // Explicit lifecycle closure targets an owned page by ID and does
            // not use DOM refs. Keep admission/ownership checks, but do not
            // require an AI snapshot after the user has returned control.
            control.begin(event, context, true);
            try {
              await close(event, context);
              work.complete(event, context);
            } catch (error) {
              if (error.browserOperationUncertain)
                control.uncertain(event, context);
              throw error;
            } finally {
              control.end(event, context);
            }
          }
          respond(true, {
            ...control.status(),
            schemaVersion: 1,
            browser: work.status(task.sessionKey, selector),
            activeBrowser: work.status(),
            selectedSessionKey: task.sessionKey,
          });
          return;
        }
        if (params?.action === "view") {
          const browser = work.status(params.sessionKey, params);
          if (!params.sessionKey || !browser)
            throw new Error("This conversation has no matching browser task");
          if (browser.resourceState !== "live") {
            respond(true, {
              ...control.status(),
              schemaVersion: 1,
              browser,
              activeBrowser: work.status(),
              selectedSessionKey: params.sessionKey,
            });
            return;
          }
          const activeBrowser = work.status();
          const currentControl = control.status();
          if (
            activeBrowser?.targetId === browser.targetId &&
            currentControl.inFlight === 0 &&
            ["ai", "human"].includes(currentControl.mode)
          ) {
            respond(true, {
              ...control.status(),
              schemaVersion: 1,
              browser,
              activeBrowser,
              selectedSessionKey: params.sessionKey,
            });
            return;
          }
          if (activeBrowser?.phase === "working")
            throw new Error("Another browser task is still working");
          const event = {
            toolName: "browser",
            runId: "viewer",
            toolCallId: crypto.randomUUID(),
            params: { action: "focus", targetId: browser.targetId },
          };
          const context = { sessionKey: params.sessionKey };
          control.begin(event, context);
          try {
            await focus(event, context);
            work.select(params.sessionKey, params);
          } catch (error) {
            if (error.browserOperationUncertain)
              control.uncertain(event, context);
            throw error;
          } finally {
            control.end(event, context);
          }
          respond(true, {
            ...control.status(),
            schemaVersion: 1,
            browser: work.status(params.sessionKey, params),
            activeBrowser: work.status(),
            selectedSessionKey: params.sessionKey,
          });
          return;
        }
        const state = control.status(params?.sessionKey);
        if (params?.action === "cancel-queued") {
          if (!params.sessionKey) throw new Error("Conversation is required");
          control.cancelQueued({
            sessionKey: params.sessionKey,
            runId: params.runId,
          });
          respond(true, control.status(params.sessionKey));
          return;
        }
        if (["retain", "unretain"].includes(params?.action)) {
          if (
            state.mode !== "ai" ||
            state.inFlight ||
            !(params.browserTaskId || params.toolCallId)
          )
            throw new Error(
              "Browser control must be returned before changing retention",
            );
          const selected = work.status(params.sessionKey, params);
          taskControl.check(
            {
              toolName: "browser",
              params: { action: "close", targetId: selected?.targetId },
            },
            { sessionKey: params.sessionKey },
          );
          const browser = work.setRetained(
            params.sessionKey,
            params,
            params.action === "retain",
          );
          respond(true, {
            ...state,
            schemaVersion: 1,
            browser,
            activeBrowser: work.status(),
            lifecycle: work.lifecycle(idleMs),
            selectedSessionKey: params.sessionKey,
          });
          return;
        }
        const candidate = () =>
          !taskControl.has() &&
          idleMs > 0 &&
          state.mode === "ai" &&
          state.inFlight === 0
            ? work.idleCandidate(idleMs)
            : null;
        if (params?.action === "idle-tasks") {
          respond(true, {
            tasks:
              state.mode === "ai" && !state.inFlight
                ? work.idleTasks(idleMs)
                : [],
          });
          return;
        }
        if (params?.action === "idle-candidate") {
          respond(true, { candidate: candidate(), idleTimeoutMs: idleMs });
          return;
        }
        if (params?.action === "idle-begin") {
          const eligible = candidate();
          if (!eligible || eligible.revision !== params.revision)
            throw new Error("Browser work changed before idle suspension");
          respond(
            true,
            control.command({
              action: "admin-begin",
              operation: "stop",
              callId: params.callId,
            }),
          );
          return;
        }
        if (["idle-end", "idle-uncertain"].includes(params?.action)) {
          const event = {
            toolName: "browser",
            runId: "wrapper",
            toolCallId: params.callId,
            params: { action: "stop" },
          };
          if (!control.owns(event, { sessionKey: "wrapper" }))
            throw new Error("No matching idle suspension");
          if (params.action === "idle-uncertain")
            control.uncertain(event, { sessionKey: "wrapper" });
          else {
            if (params.stopped === true) work.expire();
            control.command({
              action: "admin-end",
              operation: "stop",
              callId: params.callId,
            });
          }
          respond(true, control.status());
          return;
        }
        const priorBrowser = work.status();
        const resumedWaitingTasks =
          ["release", "recover"].includes(params?.action) && priorBrowser
            ? control.waiterCount?.(priorBrowser.sessionKey)
            : undefined;
        if (["request", "resume"].includes(params?.action) && taskControl.has())
          throw new Error(
            "Return task controls before taking over the shared desktop",
          );
        if (
          ["request", "resume"].includes(params?.action) &&
          params.browserTaskId &&
          (priorBrowser?.browserTaskId !== params.browserTaskId ||
            priorBrowser?.resourceState !== "live")
        )
          throw new Error("Selected browser task changed; reopen its preview");
        const result = control.command(params);
        if (params?.sessionKey)
          Object.assign(result, control.status(params.sessionKey));
        if (params?.action === "request") work.retain();
        respond(true, {
          ...result,
          ...(resumedWaitingTasks !== undefined ? { resumedWaitingTasks } : {}),
          schemaVersion: 1,
          browser: work.status(params?.sessionKey, params),
          activeBrowser: work.status(),
          lifecycle: work.lifecycle(idleMs),
          idleTimeoutMs: idleMs,
          ...(params?.sessionKey
            ? { selectedSessionKey: params.sessionKey }
            : {}),
        });
      } catch (err) {
        respond(false, undefined, {
          code: "UNAVAILABLE",
          message: err.message,
        });
      }
    },
    { scope: "operator.admin" },
  );
}

export default {
  id: "oneclaw-browser-use",
  name: "Browser Use",
  register(api) {
    const control = processControl({ file: controlFile() });
    api.registerTool(
      (context) => createBrowserShareTool(context, { control }),
      { name: "browser_use" },
    );
    const configuredIdle = Number(
      process.env.ONECLAW_BROWSER_IDLE_MS ?? 1800000,
    );
    registerBrowserUse(api, control, {
      workFile: path.join(path.dirname(controlFile()), "sessions.json"),
      idleMs:
        configuredIdle === 0 ||
        (Number.isFinite(configuredIdle) &&
          configuredIdle >= 60000 &&
          configuredIdle <= 86400000)
          ? configuredIdle
          : 1800000,
    });
  },
};

function controlFile() {
  return path.join(
    process.env.OPENCLAW_STATE_DIR || path.join(os.homedir(), ".openclaw"),
    "browser-use",
    "control.json",
  );
}
