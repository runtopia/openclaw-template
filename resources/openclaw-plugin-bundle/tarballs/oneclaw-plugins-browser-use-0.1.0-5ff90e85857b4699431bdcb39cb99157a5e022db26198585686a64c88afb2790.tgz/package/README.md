# Browser Use

Independent Gateway plugin for Web/Desktop browser handoff. Does not require OneClaw Channel or patch OpenClaw core.

- `before_tool_call` closes admission to native browser, exec, process, gateway and nodes calls before takeover.
- Tracks in-flight managed calls, drains them before grant, and requires a new successful browser snapshot after handback.
- `browseruse.control` is operator.admin only. The Runtime Wrapper owns VNC input transport and must terminate that transport before release/recover.
- State persists privately under `$OPENCLAW_STATE_DIR/browser-use/control.json`. Restart during handoff stays paused. Unfinished leases never expire into an unsafe grant.
- OpenClaw 2026.7.1-2 `tools.invoke` dispatches before hooks without guaranteed after hooks. Unscoped managed calls are explicitly rejected; normal agent runs and Wrapper's tracked browser start are supported.

## Boundary

This coordinates cooperative managed Agent browser use, not arbitrary processes with access to the container. Direct admin browser.request/CLI/CDP, other MCP browser tools and scripts detached outside the managed exec lifecycle are outside interception. Do not advertise full isolation from code execution. A stuck/missing after hook holds takeover closed and needs investigation; this plugin does not silently drop active leases.

A blocked tool does not suspend an entire conversational turn. `browser_use action=wait` waits for explicit handback and supports cancellation; waiting agents then obtain a fresh snapshot of their task target. New Web/mobile clients can submit an ordinary continuation message for an already-ended original conversation after an explicit handback. Unknown/legacy clients retain the manual continue-message fallback; this is not a general-purpose Task pause/resume RPC.

Each conversation binds an explicit task target instead of relying on Chromium's shared lastTargetId. Supported Gateway hosts focus that target before observing or acting. Successful snapshots after handback authorize only the same session/target/epoch. Control responses expose schemaVersion=1 and origin-only browser metadata for Web, iOS and Android; release/recover report resumed waiters for the original browser conversation.

Focus is a narrow loopback request to the authenticated Wrapper's `/browser/internal/focus`. The Wrapper verifies the exact admitted run/call/session/target lease through `browseruse.control` before calling the native browser RPC. The host's `runtime.gateway.request` is restricted to official plugins and cannot supply browser admin scope; do not restore that path. Unknown focus completion retains its lease and pauses control.

Task metadata persists in private `browser-use/sessions.json`. A restart marks old CDP targets expired, preserving only safe metadata for the UI. `status` accepts a `sessionKey`, returns that conversation's `browser` plus the global `activeBrowser`; authenticated `view` focuses a live owned task while participating in the same admission/drain protocol. Older clients can continue using workspace status.

The Wrapper suspends Chromium after all managed tasks have completed and have had no operations or viewers for 30 minutes. Any live/failed/cancelled task, human-retained page, unknown page, controller, or in-flight operation prevents suspension. Human takeover retains all current task pages because users can switch tabs. Cookies/profile data stay on the persistent volume; task pages become expired and the next browser task opens a fresh tab. `ONECLAW_BROWSER_IDLE_MS=0` disables suspension; otherwise the supported range is 60000–86400000 ms. This is not an expiry policy for control leases.

## Development integration

Canonical source lives here. While testing the feature branch, copy this directory into a development image at `/opt/openclaw-browser-use` (owned by root or the Runtime user), and set `ONECLAW_BROWSER_USE_ENABLED=1` in the matching Template feature build. This is a development image, not an npm release or production bundle change. Follow repository release/bundle rules when integrating into develop.

Run `npm test` in this package.

## Share a stable browser entry

The `browser_use` tool accepts `{"action":"share"}` and `{"action":"wait"}`. Share verifies the Runtime through the existing authenticated `/runtime/personality` endpoint and returns a stable `/browser-use/<workspaceId>` URL. The model sends that URL as ordinary chat text; the tool does not send messages or create login tickets. Clients check workspace ownership through the existing authenticated runtime-session API when the link is opened. Wait does not fetch identity, reserve an in-flight browser operation, or release human control.

The tool reuses the public `app_url` returned by the authenticated platform API (configured by the existing `NEXT_PUBLIC_APP_URL`/External.app_url). `ONECLAW_BROWSER_USE_WEB_URL` remains an optional explicit override. Non-production APIs without a configured Web origin fail clearly instead of guessing the production site. The link is for the Workspace's current shared browser, not a Session snapshot. Runtime credentials, platform identity response bodies, and one-time login tickets are never returned to the model.

Credentials are resolved from the shared `@oneclaw-plugins/instance-credential` closure used by Channel/Integrations. If this plugin consumes the environment secret first, it retains the same closure and removes the secret from the child-process environment. Never put the secret back into process.env.
