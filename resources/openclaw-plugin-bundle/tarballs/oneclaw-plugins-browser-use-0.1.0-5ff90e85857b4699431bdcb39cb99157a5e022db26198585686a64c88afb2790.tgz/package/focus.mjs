import { resolveBrowserShareCredential } from './share.mjs';

// The host's runtime.gateway API is restricted to official plugins and gives
// synthetic clients operator.write, while browser.request needs operator.admin.
// Use the existing authenticated Wrapper, with a narrowly validated live lease.
export function createTaskFocus({ env = process.env, fetchImpl = fetch, credentialScope = globalThis } = {}) {
  return async (event, context) => {
    const port = Number(env.PORT || 8080);
    if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('Browser focus service is not configured');
    const credential = resolveBrowserShareCredential(env, credentialScope);
    let response;
    try {
      response = await fetchImpl(`http://127.0.0.1:${port}/browser/internal/focus`, {
        method: 'POST', redirect: 'error',
        headers: { Authorization: credential.authorizationHeader(), 'Content-Type': 'application/json' },
        body: JSON.stringify({ runId: event.runId || context?.runId, toolCallId: event.toolCallId || context?.toolCallId,
          sessionKey: context?.sessionKey || context?.sessionId || '', targetId: event.params.targetId }),
        signal: AbortSignal.timeout(8000),
      });
      const result = await response.json();
      if (response.ok && result.ok === true) return;
      const error = new Error('Browser task tab could not be focused');
      error.browserOperationUncertain = !['browser_focus_failed', 'browser_control_conflict'].includes(result.errorCode);
      throw error;
    } catch (error) {
      if (error.browserOperationUncertain === undefined) error.browserOperationUncertain = true;
      throw error;
    }
  };
}
