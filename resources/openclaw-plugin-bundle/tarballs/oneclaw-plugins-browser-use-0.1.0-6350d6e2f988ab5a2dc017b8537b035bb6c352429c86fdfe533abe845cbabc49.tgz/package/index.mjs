import os from 'node:os';
import { createBrowserShareTool } from './share.mjs';
import path from 'node:path';
import { processControl, MANAGED_TOOLS } from './control.mjs';
import { BROWSER_USE_GUIDANCE, managedBrowserParams } from './policy.mjs';
import { createBrowserWork } from './work.mjs';

export function registerBrowserUse(api, control) {
  const work = control.work ??= createBrowserWork();
  api.on('before_tool_call', (event, context) => {
    if (MANAGED_TOOLS.has(event.toolName) && !(event.runId || context?.runId)) {
      return { block: true, blockReason: 'Browser Use requires a managed agent run with completion hooks; unscoped tools.invoke is not supported for browser/exec control.' };
    }
    try {
      const managed = managedBrowserParams(event);
      const params = managed ? work.prepare(managed, context) : undefined;
      control.begin(params ? { ...event, params } : event, context);
      if (params?.targetId && ['snapshot', 'screenshot', 'navigate', 'act'].includes(params.action) && api.runtime?.gateway?.request) {
        return api.runtime.gateway.request('browser.request', {
          method: 'POST', path: '/tabs/focus', query: { profile: 'openclaw' }, body: { targetId: params.targetId }, timeoutMs: 5000,
        }).then(() => ({ params })).catch(() => {
          control.end({ ...event, params, error: 'Task tab focus failed' }, context);
          return { block: true, blockReason: 'Browser Use: task tab could not be focused. List tabs and select a valid targetId before continuing.' };
        });
      }
      return params ? { params } : undefined;
    }
    catch (err) { return { block: true, blockReason: err.message }; }
  }, { priority: -100000 });
  api.on('after_tool_call', (event, context) => { control.end(event, context); work.complete(event, context); });
  api.on('agent_end', (event, context) => work.finish(event, context));
  api.on('before_prompt_build', () => ({ appendSystemContext: BROWSER_USE_GUIDANCE }));
  api.registerGatewayMethod('browseruse.control', async ({ params, respond }) => {
    try {
      const browser = work.status();
      const resumedWaitingTasks = ['release', 'recover'].includes(params?.action) && browser ? control.waiterCount?.(browser.sessionKey) : undefined;
      respond(true, { ...control.command(params), ...(resumedWaitingTasks !== undefined ? { resumedWaitingTasks } : {}), schemaVersion: 1, browser });
    }
    catch (err) { respond(false, undefined, { code: 'UNAVAILABLE', message: err.message }); }
  }, { scope: 'operator.admin' });
}

export default {
  id: 'oneclaw-browser-use', name: 'Browser Use',
  register(api) {
    const control = processControl({ file: path.join(process.env.OPENCLAW_STATE_DIR || path.join(os.homedir(), '.openclaw'), 'browser-use', 'control.json') });
    api.registerTool((context) => createBrowserShareTool(context, { control }), { name: 'browser_use' });
    registerBrowserUse(api, control);
  },
};
