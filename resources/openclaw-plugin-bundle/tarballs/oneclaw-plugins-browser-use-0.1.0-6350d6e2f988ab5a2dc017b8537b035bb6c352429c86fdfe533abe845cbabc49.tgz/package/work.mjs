const PAGE_ACTIONS = new Set(['focus', 'close', 'snapshot', 'screenshot', 'navigate', 'act', 'pdf', 'console', 'upload', 'dialog', 'resize']);
const ID = /^[A-Za-z0-9_-]{1,128}$/;

export function browserDisplayUrl(value) {
  try {
    const url = new URL(value);
    if (url.protocol === 'about:') return url.pathname === 'blank' ? 'about:blank' : undefined;
    if (!['https:', 'http:'].includes(url.protocol)) return undefined;
    return url.origin; // Paths, queries and fragments may contain login credentials.
  } catch { return undefined; }
}

// Logical task targets share one Chromium, never its global lastTargetId.
export function createBrowserWork() {
  const sessions = new Map();
  let current;
  const key = (context) => context?.sessionKey || context?.sessionId || '';
  function prepare(params, context) {
    const sessionKey = key(context);
    const bound = sessions.get(sessionKey);
    if (!PAGE_ACTIONS.has(params.action)) return params;
    const explicit = params.targetId || params.request?.targetId;
    const targetId = explicit || bound?.targetId;
    if (!targetId || !ID.test(targetId)) throw new Error('Browser Use: select a task tab explicitly with targetId, or open a new task tab first. Do not use the shared browser default tab.');
    for (const [owner, work] of sessions) {
      if (owner !== sessionKey && work.targetId === targetId) throw new Error('Browser Use: this tab belongs to another conversation. Open a separate task tab.');
    }
    return { ...params, targetId, ...(params.request ? { request: { ...params.request, targetId } } : {}) };
  }
  function complete(event, context) {
    const sessionKey = key(context);
    if (!sessionKey || event.toolName !== 'browser') return;
    const prior = sessions.get(sessionKey);
    const params = event.params || {};
    const details = event.result?.details || {};
    const failed = Boolean(event.error || event.result?.isError);
    if (params.action === 'close' && !failed) {
      if (prior?.targetId === params.targetId) sessions.delete(sessionKey);
      if (current?.sessionKey === sessionKey) current = undefined;
      return;
    }
    const targetId = details.targetId || params.targetId || prior?.targetId;
    if (!targetId || !ID.test(targetId)) return;
    const work = {
      sessionKey, runId: event.runId || context?.runId, targetId,
      displayUrl: browserDisplayUrl(details.url) || prior?.displayUrl,
      phase: failed ? 'failed' : 'working',
      action: params.action, updatedAt: Date.now(),
      ...(failed ? { errorCode: 'browser_operation_failed' } : {}),
    };
    sessions.set(sessionKey, work);
    if (sessions.size > 128) sessions.delete(sessions.keys().next().value);
    current = work;
  }
  function finish(event, context) {
    if (!current || (context?.runId && context.runId !== current.runId) || key(context) !== current.sessionKey) return;
    current = { ...current, phase: /abort|cancel/i.test(event.error || '') ? 'cancelled' : event.success === false ? 'failed' : 'completed', updatedAt: Date.now() };
    sessions.set(current.sessionKey, current);
  }
  return { prepare, complete, finish, status: () => current ? { ...current } : null };
}
