const ID = /^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/;

function origin(value) {
  const url = new URL(value);
  if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password || url.search || url.hash || url.pathname !== '/') throw new Error('Browser Use web URL must be a configured HTTP(S) origin');
  return url.origin;
}

export function createBrowserShareTool(context = {}, { env = process.env, fetchImpl = fetch } = {}) {
  return {
    name: 'browser_use',
    label: 'Browser Use',
    description: 'Use action=share to get the current Runtime browser entry URL. Send the returned URL verbatim in chat; clients render it as a Browser Use card. This does not send a message, start a browser or grant control. Never construct a URL yourself.',
    parameters: { type: 'object', additionalProperties: false, properties: { action: { type: 'string', enum: ['share'] } }, required: ['action'] },
    async execute(_callId, args, signal) {
      if (args?.action !== 'share' || Object.keys(args).some((key) => key !== 'action')) throw new Error('Use browser_use with only action="share"; Runtime identity cannot be supplied by the model');
      const trustedSession = typeof context.sessionKey === 'string' && context.sessionKey.length > 0;
      const channelSession = trustedSession && /:oneclaw:direct:session_[A-Za-z0-9_-]+$/.test(context.sessionKey);
      if (!trustedSession || (!channelSession && context.senderIsOwner !== true)) throw new Error('Browser Use share requires a trusted OneClaw session or authenticated owner session');
      const instance = env.ONECLAW_INSTANCE_ID?.trim();
      const secret = env.ONECLAW_INSTANCE_SECRET?.trim();
      if (!instance || !secret) throw new Error('Browser Use share requires a platform-managed cloud Runtime');
      const webOrigin = origin(env.ONECLAW_BROWSER_USE_WEB_URL || 'https://www.oneclaw.net');
      const api = new URL(env.ONECLAW_API_URL || 'https://www.oneclaw.net/api/v1');
      if (!['https:', 'http:'].includes(api.protocol) || api.username || api.password || api.search || api.hash) throw new Error('Invalid Runtime API configuration');
      api.pathname = `${api.pathname.replace(/\/$/, '') || '/api/v1'}/runtime/personality`;
      let response;
      try {
        response = await fetchImpl(api, {
          method: 'GET', redirect: 'error',
          headers: { Authorization: `Bearer ${secret}`, 'X-OneClaw-Instance-ID': instance, Accept: 'application/json' },
          signal: signal ? AbortSignal.any([signal, AbortSignal.timeout(8000)]) : AbortSignal.timeout(8000),
        });
      } catch { throw new Error('Browser Use could not verify the current Runtime with the platform'); }
      if (!response.ok) throw new Error(`Browser Use identity lookup failed (HTTP ${response.status})`);
      let identity;
      try { identity = await response.json(); } catch { throw new Error('Browser Use received an invalid platform identity response'); }
      const workspaceId = identity?.workspace?.id;
      if (identity?.instance_id !== instance || typeof workspaceId !== 'string' || !ID.test(workspaceId)) throw new Error('Browser Use identity does not match this Runtime');
      const url = `${webOrigin}/browser-use/${workspaceId}`;
      return {
        content: [{ type: 'text', text: url }],
        details: { kind: 'browser-use-link', url, delivery: 'not_sent' },
      };
    },
  };
}
