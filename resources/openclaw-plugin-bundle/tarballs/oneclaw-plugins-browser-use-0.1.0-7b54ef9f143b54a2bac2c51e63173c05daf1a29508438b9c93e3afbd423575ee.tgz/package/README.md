# Browser Use

## Task runtime update

Task control advertises `controlProtocolVersion:2`. New leases opt in with
`protocolVersion:2`; mutations carry `expectedControlEpoch`. Pause, resume and
handback advance the persisted epoch. Input completion can settle its original
lease after a pause, but old queued inputs cannot start. A granted controller
must use a frame captured after `grantedAt`.

OneClaw Session handback records its continuation intent atomically with release.
The delivery worker retries the same handoff ID through the authenticated
`/runtime/channel/browser-handbacks` API, which submits through the existing
Channel command lane. Clients must not send another continuation when the
response includes `continuation`. Deploy the API before this plugin. Original
waiting Runs are woken directly and do not also enqueue a continuation.

Template images that validate the pinned strict-target patch set
`ONECLAW_BROWSER_STRICT_TARGET=1`; those hosts do not need the extra focus callback
before snapshot, screenshot, navigation or actions. Other hosts retain the
existing focus path. This flag must never be enabled on an unvalidated host.

Task previews carry an opaque input-frame token when supplied by the new Runtime
page connection pool. Full viewers can use the read-only binary task media stream;
the original authenticated screenshot RPC remains the rollout fallback.

Independent Gateway plugin for Web/Desktop browser handoff. Does not require OneClaw Channel or patch OpenClaw core.

- `before_tool_call` closes admission to native browser, exec, process, gateway and nodes calls before takeover.
- Tracks in-flight managed calls, drains them before grant, and requires a new successful browser snapshot after handback.
- `browseruse.control` is operator.admin only. The Runtime Wrapper owns VNC input transport and must terminate that transport before release/recover.
- State persists privately under `$OPENCLAW_STATE_DIR/browser-use/control.json`. Restart during handoff stays paused. Unfinished leases never expire into an unsafe grant.
- OpenClaw 2026.7.1-2 `tools.invoke` dispatches before hooks without guaranteed after hooks. Unscoped managed calls are explicitly rejected; normal agent runs and Wrapper's tracked browser start are supported.

## Boundary

This coordinates cooperative managed Agent browser use, not arbitrary processes with access to the container. Direct admin browser.request/CLI/CDP, other MCP browser tools and scripts detached outside the managed exec lifecycle are outside interception. Do not advertise full isolation from code execution. A stuck/missing after hook holds takeover closed and needs investigation; this plugin does not silently drop active leases.

A blocked tool does not suspend an entire conversational turn. `browser_use action=wait` waits for explicit handback and supports cancellation; waiting agents then obtain a fresh snapshot of their task target. Managed OneClaw handback durably submits continuation through Channel for an ended original Run. Authenticated native Dashboard owner Sessions use existing `chat.send` via the secret-protected loopback Wrapper adapter; the task registry verifies owner provenance and current Run state. The handoff ID fixes the native idempotency key. This does not relabel Dashboard Sessions as Channel Sessions or expose a public continuation endpoint. Clients only retain their old continuation fallback when the Runtime omits a continuation receipt; this is not a general-purpose Task pause/resume RPC.

Each conversation binds an explicit task target instead of relying on Chromium's shared lastTargetId. Validated strict-target hosts act without changing the foreground; older hosts focus that target before observing or acting. Successful snapshots after handback authorize only the same session/target/epoch. Control responses expose schemaVersion=1 and origin-only browser metadata for Web, iOS and Android; release/recover report resumed waiters for the original browser conversation.

Focus is a narrow loopback request to the authenticated Wrapper's `/browser/internal/focus`. The Wrapper verifies the exact admitted run/call/session/target lease through `browseruse.control` before calling the native browser RPC. The host's `runtime.gateway.request` is restricted to official plugins and cannot supply browser admin scope; do not restore that path. Unknown focus completion retains its lease and pauses control.

Task metadata persists in private `browser-use/sessions.json`. A restart marks old CDP targets expired, preserving only safe metadata for the UI. `status` accepts a `sessionKey`, returns that conversation's `browser` plus the global `activeBrowser`; authenticated `view` focuses a live owned task while participating in the same admission/drain protocol. Older clients can continue using workspace status.

The Wrapper suspends Chromium after all managed tasks have completed and have had no operations or viewers for 30 minutes. Any live/failed/cancelled task, human-retained page, unknown page, controller, or in-flight operation prevents suspension. Human takeover retains all current task pages because users can switch tabs. Cookies/profile data stay on the persistent volume; task pages become expired and the next browser task opens a fresh tab. `ONECLAW_BROWSER_IDLE_MS=0` disables suspension; otherwise the supported range is 60000–86400000 ms. This is not an expiry policy for control leases.

## Development integration

Canonical source lives here. While testing the feature branch, copy this directory into a development image at `/opt/openclaw-browser-use` (owned by root or the Runtime user), and set `ONECLAW_BROWSER_USE_ENABLED=1` in the matching Template feature build. This is a development image, not an npm release or production bundle change. Follow repository release/bundle rules when integrating into develop.

Run `npm test` in this package.

## Share a stable browser entry

The `browser_use` tool accepts `{"action":"share"}` and `{"action":"wait"}`. Share verifies the Runtime through the existing authenticated `/runtime/personality` endpoint and returns an owner-gated `/browser-use/<workspaceId>?sessionKey=…&browserTaskId=…` URL for the caller’s exact current task. Sharing without a task fails; session/task identity is never accepted from model arguments. The model sends that URL as ordinary chat text; the tool does not send messages or create login tickets. Clients check workspace ownership through the existing authenticated runtime-session API when the link is opened. Wait does not fetch identity, reserve an in-flight browser operation, or release human control.

The tool reuses the public `app_url` returned by the authenticated platform API (configured by the existing `NEXT_PUBLIC_APP_URL`/External.app_url). `ONECLAW_BROWSER_USE_WEB_URL` remains an optional explicit override. Non-production APIs without a configured Web origin fail clearly instead of guessing the production site. The link pins the specific task across other Sessions and later tasks. Live pages and archived final frames use the same task identity; neither the Web entry nor an invalid selector may fall back to the shared desktop. Runtime credentials, platform identity response bodies, and one-time login tickets are never returned to the model.

Credentials are resolved from the shared `@oneclaw-plugins/instance-credential` closure used by Channel/Integrations. If this plugin consumes the environment secret first, it retains the same closure and removes the secret from the child-process environment. Never put the secret back into process.env.

## Task-addressed previews and control

Browser tasks have a server-generated `browserTaskId` and a Runtime `generation`.
`browseruse.control` status/view accepts `toolCallId` or `browserTaskId` in addition
to the owning session. Ordinary new runs create separate task identities; reuse
of a tab archives the prior task and preserves its final frame. Continuation
keeps its task identity. Native timestamp-only previews are rejected.

`browseruse.task` provides page-scoped status/request/resume/pause/release/recover
and input through the authenticated Runtime broker. A human-controlled task
blocks that task's AI operations; other tasks can use their own browser pages.
Shared exec/process/gateway/nodes and global desktop takeover remain blocked
while a task lease is held. Input leases are settled only after acknowledgement;
uncertain input stays paused. Foreground status heartbeats do not silently
restore write permission. This isolates page controls, not cookies or profiles.

Completed, failed and cancelled tasks can be retained, explicitly unretained,
or closed with `close-task`. Closing saves a real frame first. Idle tasks are
reclaimed individually; the existing idle browser stop still protects unknown
pages and retained work. Snapshot files are owner-only, separate from task
metadata. Historical frames never focus or reopen pages. Queue admission is
FIFO, bounded to 60 seconds, and exposes queue position/cancellation.
