import { resolveBrowserShareCredential } from './share.mjs';

// Durable intent is written atomically with lease release by task-control.
// Canonical sessions use the existing Channel lane; authenticated Dashboard
// owners use native chat.send. No client needs
// to remain connected and an ambiguous HTTP response is retried with the same ID.
export function createHandbackDelivery({ taskControl, work, env = process.env, fetchImpl = fetch, credentialScope = globalThis }) {
  let running;
  async function deliver() {
    for (const item of taskControl.pendingHandbacks()) {
      const sessionId = /:oneclaw:direct:(session_[A-Za-z0-9_-]+)$/.exec(item.sessionKey)?.[1];
      // Channel admission owns canonical Session supersession and idempotency.
      const state = !sessionId ? work.handbackState?.(item) : undefined;
      if (state === 'accepted') { taskControl.settleHandback(item.handoffId, 'accepted'); continue; }
      if (state === 'active') continue;
      if (state === 'cancelled' || state === 'superseded') { taskControl.settleHandback(item.handoffId, 'cancelled'); continue; }
      const task = work.status(item.sessionKey, { browserTaskId: item.browserTaskId });
      if (!task || !task.needsContinuation || ['cancelled', 'expired'].includes(task.phase)) {
        taskControl.settleHandback(item.handoffId, 'cancelled'); continue;
      }
      if (!sessionId) {
        // Authenticated Dashboard owner sessions use the existing native chat
        // lane. Their ID cannot be relabelled as a OneClaw Channel Session.
        if (!work.isOwnerSession?.(item.sessionKey)) continue;
        const port = Number(env.PORT || 8080);
        if (!Number.isInteger(port) || port < 1 || port > 65535) continue;
        try {
          const credential = resolveBrowserShareCredential(env, credentialScope);
          const response = await fetchImpl(`http://127.0.0.1:${port}/browser/internal/handback`, {
            method: 'POST', redirect: 'error', signal: AbortSignal.timeout(12000),
            headers: { Authorization: credential.authorizationHeader(), 'Content-Type': 'application/json' },
            body: JSON.stringify({ handoffId: item.handoffId }),
          });
          const result = await response.json();
          if (response.ok && result.accepted === true) taskControl.settleHandback(item.handoffId, 'accepted');
        } catch { /* Ambiguous admission is retried with the same native Run ID. */ }
        continue;
      }
      const runtimeId = env.ONECLAW_RUNTIME_ID || env.ONECLAW_INSTANCE_ID;
      if (!sessionId || !runtimeId || !env.ONECLAW_API_URL) continue;
      const url = new URL(env.ONECLAW_API_URL);
      if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) continue;
      url.pathname = `${url.pathname.replace(/\/$/, '') || '/api/v1'}/runtime/channel/browser-handbacks`;
      const credential = resolveBrowserShareCredential(env, credentialScope);
      try {
        const response = await fetchImpl(url, {
          method: 'POST', redirect: 'error', signal: AbortSignal.timeout(8000),
          headers: { Authorization: credential.authorizationHeader(), 'X-OneClaw-Instance-ID': runtimeId, 'Content-Type': 'application/json' },
          body: JSON.stringify({ sessionId, runId: item.runId, browserTaskId: item.browserTaskId, handoffId: item.handoffId }),
        });
        const result = await response.json();
        if (response.ok && result.accepted === true) taskControl.settleHandback(item.handoffId, 'accepted');
        else if (['browser_task_cancelled', 'browser_task_superseded'].includes(result.error?.code || result.code)) taskControl.settleHandback(item.handoffId, 'cancelled');
      } catch { /* Keep durable intent; never manufacture success or replay page input. */ }
    }
  }
  const tick = () => (running ??= deliver().finally(() => { running = undefined; }));
  const timer = setInterval(() => { void tick().catch(() => {}); }, 2000);
  timer.unref();
  return { tick, close: () => clearInterval(timer) };
}
