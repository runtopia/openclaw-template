import { resolveBrowserShareCredential } from './share.mjs';

// Read-only capture is separate from agent admission: it never focuses a tab,
// starts Chromium, changes a control lease, or writes screenshots to disk.
export function createTaskPreview({ env = process.env, fetchImpl = fetch, credentialScope = globalThis } = {}) {
  return async (targetId, options = {}) => {
    const port = Number(env.PORT || 8080);
    if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('Preview is unavailable');
    const credential = resolveBrowserShareCredential(env, credentialScope);
    const response = await fetchImpl(`http://127.0.0.1:${port}/browser/internal/preview`, {
      method: 'POST', redirect: 'error',
      headers: { Authorization: credential.authorizationHeader(), 'Content-Type': 'application/json' },
      body: JSON.stringify({ targetId, viewer: options.viewer === true, minFrameAt:options.minFrameAt || 0 }), signal: AbortSignal.timeout(5000),
    });
    const result = await response.json();
    if (!response.ok || !/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(result.image || '') || result.image.length > 700000) throw new Error('Preview is unavailable');
    return options.metadata === true ? { image: result.image, ...(typeof result.frameToken === 'string' ? { frameToken: result.frameToken } : {}), ...(Number.isFinite(result.capturedAt) ? {capturedAt:result.capturedAt} : {}) } : result.image;
  };
}

export function registerTaskPreview(api, work, capture, { now = Date.now } = {}) {
  const cache = new Map();
  let inFlight = 0;
  api.registerGatewayMethod('browseruse.preview', async ({ params, respond }) => {
    try {
      const native = typeof params?.nativeSessionId === 'string';
      const task = native ? work.nativeStatus?.(params.nativeSessionId, params) : work.status(params?.sessionKey, params);
      const runId = task?.previewRunId || task?.runId;
      const exact = Boolean(params?.browserTaskId || params?.toolCallId);
      const matches = exact ? Boolean(task) : native ? false
        : params?.sessionKey && Array.isArray(params.runIds) && params.runIds.length <= 16 && params.runIds.includes(runId);
      if (!matches || !runId) throw new Error('No matching browser task');
      if (task.resourceState && task.resourceState !== 'live') {
        const saved = work.frame?.(task.sessionKey, params);
        if (!saved) throw new Error('No saved task frame');
        respond(true, { ...saved, resourceState: task.resourceState, phase: task.phase }); return;
      }
      if (task.phase === 'expired') throw new Error('Browser task expired');
      const after=Number.isFinite(params.after) && params.after>0 ? params.after : 0;
      if(after>now()+1000)throw new Error('Invalid frame time');
      const key = `${task.browserTaskId || task.sessionKey}:${runId}:${task.targetId}:${task.generation || ''}:${params.viewer === true}:${after}`;
      let entry = cache.get(key);
      if (!entry || now() - entry.at >= (params.viewer === true ? 200 : 900)) {
        if (inFlight >= 2) throw new Error('Preview is busy');
        inFlight++;
        entry = { at: now(), promise: Promise.resolve().then(() => capture(task.targetId, { viewer: params.viewer === true, metadata: true, minFrameAt:after })).finally(() => { inFlight--; }) };
        cache.set(key, entry);
        if (cache.size > 128) cache.delete(cache.keys().next().value);
        entry.promise.catch(() => { if (cache.get(key) === entry) cache.delete(key); });
      }
      const captured = await entry.promise;
      const image = typeof captured === 'string' ? captured : captured.image;
      const current = work.status(task.sessionKey, params);
      if (current?.targetId !== task.targetId || (current?.previewRunId || current?.runId) !== runId || current.phase === 'expired') throw new Error('Browser task changed');
      respond(true, { browserTaskId: task.browserTaskId, generation: task.generation, resourceState: task.resourceState, sessionKey: task.sessionKey, runId, targetId: task.targetId, image, ...(captured?.frameToken ? { frameToken: captured.frameToken } : {}), capturedAt: Number.isFinite(captured?.capturedAt) ? captured.capturedAt : entry.at, phase: current.phase, displayUrl: current.displayUrl });
    } catch { respond(false, undefined, { code: 'UNAVAILABLE', message: 'Browser task preview is temporarily unavailable' }); }
  }, { scope: 'operator.read' });
}
