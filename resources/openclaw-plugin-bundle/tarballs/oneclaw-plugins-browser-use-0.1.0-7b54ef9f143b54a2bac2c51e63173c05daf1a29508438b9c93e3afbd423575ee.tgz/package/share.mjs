const INSTANCE_CREDENTIAL_KEY = Symbol.for('@oneclaw-plugins/instance-credential');

export function resolveBrowserShareCredential(env, scope = globalThis) {
  const existing = scope[INSTANCE_CREDENTIAL_KEY];
  if (existing && typeof existing.authorizationHeader === 'function') return existing;
  const secret = env.ONECLAW_INSTANCE_SECRET?.trim();
  if (!secret) throw new Error('Browser Use Runtime credential is unavailable; check the platform credential configuration');
  const credential = Object.freeze({ authorizationHeader: () => `Bearer ${secret}` });
  scope[INSTANCE_CREDENTIAL_KEY] = credential;
  delete env.ONECLAW_INSTANCE_SECRET;
  return credential;
}

const ID = /^[A-Za-z0-9][A-Za-z0-9_-]{0,127}$/;

function origin(value) {
  const url = new URL(value);
  if (!['https:', 'http:'].includes(url.protocol) || url.username || url.password || url.search || url.hash || url.pathname !== '/') throw new Error('Browser Use web URL must be a configured HTTP(S) origin');
  return url.origin;
}

export function createBrowserShareTool(context = {}, { env = process.env, fetchImpl = fetch, credentialScope = globalThis, control } = {}) {
  return {
    name: 'browser_use',
    label: 'Browser Use',
    description: 'status reads browser control state even while paused, without acquiring an execution lease. Use native browser status for process health, and browser for tabs/open/navigation/snapshots. share returns the browser card entry URL. wait is only for live human/waiting control and explicit handback. In ai mode proceed without waiting. These actions do not send messages or grant control.',
    parameters: { type: 'object', additionalProperties: false, properties: { action: { type: 'string', enum: ['status', 'share', 'wait'] } }, required: ['action'] },
    async execute(_callId, args, signal) {
      if (!['status', 'share', 'wait'].includes(args?.action) || Object.keys(args).some((key) => key !== 'action')) throw new Error('Use browser_use with only action="status", action="share" or action="wait"; Runtime identity cannot be supplied by the model');
      const trustedSession = typeof context.sessionKey === 'string' && context.sessionKey.length > 0 && context.sessionKey.length <= 512 && !/[\x00-\x1f]/.test(context.sessionKey);
      const channelSession = trustedSession && /:oneclaw:direct:session_[A-Za-z0-9_-]+$/.test(context.sessionKey);
      if (!trustedSession || (!channelSession && context.senderIsOwner !== true)) throw new Error('Browser Use share requires a trusted OneClaw session or authenticated owner session');
      if (args.action === 'status') {
        if (!control) throw new Error('Browser Use control service is unavailable');
        const state = control.status(context.sessionKey);
        const scoped = control.taskControl?.stateFor?.(context.sessionKey);
        const scopedMode = scoped?.mode || control.taskControl?.modeFor(context.sessionKey);
        const details = { kind: 'browser-use-control-status', ...state,
          mode: state.mode !== 'ai' ? state.mode : scopedMode || state.mode,
          inFlight: state.mode === 'ai' && scoped ? scoped.inFlight : state.inFlight,
          controlScope: state.mode !== 'ai' ? 'runtime' : scoped?.controlScope || 'task' };
        return { content: [{ type: 'text', text: JSON.stringify(details) }], details };
      }
      if (args.action === 'wait') {
        if (!control) throw new Error('Browser Use control service is unavailable');
        const current = control.status();
        if (current.mode === 'paused') throw new Error('AI control is paused, not an active human takeover. Runtime recovery is required; waiting for handback will not fix it.');
        if (control.taskControl?.modeFor(context.sessionKey) === 'paused') throw new Error('This task control is paused. Explicit task recovery is required; waiting for handback will not fix interrupted input.');
        if (control.taskControl?.modeFor(context.sessionKey)) {
          control.work?.waiting(context);
          await control.taskControl.wait(context.sessionKey, signal);
          if (control.status().mode !== 'ai') throw new Error('Task control returned, but Runtime control is still blocked. Check the current control state before continuing.');
          return { content: [{ type: 'text', text: 'Task control returned. Obtain a fresh snapshot of this task before continuing.' }], details: { kind: 'browser-use-handback', mode: 'ai', epoch: control.status().epoch } };
        }
        if (current.mode === 'ai') return {
          content: [{ type: 'text', text: 'AI control is already active. There is no human takeover to wait for. Continue now with the native browser tool: list tabs, get a fresh snapshot, then navigate or act. Do not call browser_use wait again unless a new live response reports human/waiting.' }],
          details: { kind: 'browser-use-ready', mode: 'ai', epoch: current.epoch },
        };
        if (current.mode === 'paused') throw new Error('AI control is paused, not an active human takeover. Runtime recovery is required; waiting for handback will not fix it.');
        control.work?.waiting(context);
        const state = await control.waitForAI(signal, 900000, context.sessionKey);
        return { content: [{ type: 'text', text: 'The user returned browser control; AI control is now active. Continue with the native browser tool: list tabs and obtain a fresh snapshot of the task target. Do not wait again unless a new live response reports human/waiting.' }], details: { kind: 'browser-use-handback', mode: 'ai', epoch: state.epoch } };
      }
      const instance = env.ONECLAW_RUNTIME_ID?.trim() || env.ONECLAW_INSTANCE_ID?.trim();
      if (!instance) throw new Error('Browser Use Runtime identity is unavailable; check ONECLAW_RUNTIME_ID or ONECLAW_INSTANCE_ID');
      const credential = resolveBrowserShareCredential(env, credentialScope);
      const api = new URL(env.ONECLAW_API_URL || 'https://www.oneclaw.net/api/v1');
      if (!['https:', 'http:'].includes(api.protocol) || api.username || api.password || api.search || api.hash) throw new Error('Invalid Runtime API configuration');
      api.pathname = `${api.pathname.replace(/\/$/, '') || '/api/v1'}/runtime/personality`;
      let response;
      try {
        response = await fetchImpl(api, {
          method: 'GET', redirect: 'error',
          headers: { Authorization: credential.authorizationHeader(), 'X-OneClaw-Instance-ID': instance, Accept: 'application/json' },
          signal: signal ? AbortSignal.any([signal, AbortSignal.timeout(8000)]) : AbortSignal.timeout(8000),
        });
      } catch { throw new Error('Browser Use could not verify the current Runtime with the platform'); }
      if (!response.ok) throw new Error(`Browser Use identity lookup failed (HTTP ${response.status})`);
      let identity;
      try { identity = await response.json(); } catch { throw new Error('Browser Use received an invalid platform identity response'); }
      const workspaceId = identity?.workspace?.id;
      if (identity?.instance_id !== instance || typeof workspaceId !== 'string' || !ID.test(workspaceId)) throw new Error('Browser Use identity does not match this Runtime');
      const configuredWeb = env.ONECLAW_BROWSER_USE_WEB_URL?.trim() || identity.app_url || env.NEXT_PUBLIC_APP_URL?.trim();
      const defaultWeb = ['www.oneclaw.net', 'oneclaw.net', 'api.oneclaw.net'].includes(api.hostname) ? 'https://www.oneclaw.net' : undefined;
      if (!configuredWeb && !defaultWeb) throw new Error('Browser Use Web address is unavailable; update the platform API to expose its existing app_url configuration');
      const webOrigin = origin(configuredWeb || defaultWeb);
      const task = control?.work?.status(context.sessionKey);
      if (!task?.browserTaskId || !ID.test(task.browserTaskId)) throw new Error('Open a browser task in this conversation before sharing its page');
      const entry = new URL(`/browser-use/${workspaceId}`, webOrigin);
      entry.searchParams.set('sessionKey', context.sessionKey);
      entry.searchParams.set('browserTaskId', task.browserTaskId);
      const url = entry.href;
      return {
        content: [{ type: 'text', text: url }],
        details: { kind: 'browser-use-link', url, delivery: 'not_sent' },
      };
    },
  };
}
