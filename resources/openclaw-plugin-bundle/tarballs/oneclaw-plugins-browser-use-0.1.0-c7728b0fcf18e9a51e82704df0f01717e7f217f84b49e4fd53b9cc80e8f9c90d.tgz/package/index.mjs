import os from 'node:os';
import { createBrowserShareTool } from './share.mjs';
import path from 'node:path';
import { processControl, MANAGED_TOOLS } from './control.mjs';
import { BROWSER_USE_GUIDANCE, managedBrowserParams } from './policy.mjs';

export function registerBrowserUse(api, control) {
  api.on('before_tool_call', (event, context) => {
    if (MANAGED_TOOLS.has(event.toolName) && !(event.runId || context?.runId)) {
      return { block: true, blockReason: 'Browser Use requires a managed agent run with completion hooks; unscoped tools.invoke is not supported for browser/exec control.' };
    }
    try {
      const params = managedBrowserParams(event);
      control.begin(params ? { ...event, params } : event, context);
      return params ? { params } : undefined;
    }
    catch (err) { return { block: true, blockReason: err.message }; }
  }, { priority: -100000 });
  api.on('after_tool_call', (event, context) => control.end(event, context));
  api.on('before_prompt_build', () => ({ appendSystemContext: BROWSER_USE_GUIDANCE }));
  api.registerGatewayMethod('browseruse.control', async ({ params, respond }) => {
    try { respond(true, control.command(params)); }
    catch (err) { respond(false, undefined, { code: 'UNAVAILABLE', message: err.message }); }
  }, { scope: 'operator.admin' });
}

export default {
  id: 'oneclaw-browser-use', name: 'Browser Use',
  register(api) {
    api.registerTool((context) => createBrowserShareTool(context), { name: 'browser_use' });
    registerBrowserUse(api, processControl({ file: path.join(process.env.OPENCLAW_STATE_DIR || path.join(os.homedir(), '.openclaw'), 'browser-use', 'control.json') }));
  },
};
