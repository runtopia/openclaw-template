export const BROWSER_USE_GUIDANCE = 'Browser Use provides a preinstalled headed Chromium on Xvfb :99, visible to the user. Use the native browser tool with profile="openclaw", target="host"; load the browser-use skill for interactive browsing, screenshots or handoff. Do not launch another browser, add headless arguments, or change DISPLAY/config to work around failures. Gateway inherits DISPLAY=:99 and OPENCLAW_BROWSER_HEADLESS=0. To share the browser, call browser_use with action="share" and send the returned stable URL verbatim; the tool does not send a message. Never invent URLs or send Runtime credentials/login tickets. Public information lookup may use web_search/web_fetch. When human control is pending/active, wait without bypassing via exec/MCP/CLI/CDP. After handback get a fresh snapshot; an ended chat turn requires a new continue message.';

export function managedBrowserParams(event) {
  if (event.toolName !== 'browser') return undefined;
  const params = event.params || {};
  if (params.headless !== undefined && params.headless !== false) throw new Error('Browser Use requires headed Chromium on DISPLAY=:99; headless startup is not allowed. Use browser start with profile="openclaw", target="host".');
  if ((params.profile !== undefined && params.profile !== 'openclaw') || (params.target !== undefined && params.target !== 'host') || params.node) {
    throw new Error('Browser Use operates the visible Runtime browser only: profile="openclaw", target="host". Other profiles/nodes/sandbox do not share the preview or handoff.');
  }
  if (params.action === 'start' && ['args', 'extraArgs', 'executablePath'].some((key) => params[key] !== undefined)) {
    throw new Error('Browser Use manages Chromium launch arguments. Do not supply custom launch arguments; inspect browser status/doctor if startup fails.');
  }
  return { ...params, profile: 'openclaw', target: 'host' };
}
