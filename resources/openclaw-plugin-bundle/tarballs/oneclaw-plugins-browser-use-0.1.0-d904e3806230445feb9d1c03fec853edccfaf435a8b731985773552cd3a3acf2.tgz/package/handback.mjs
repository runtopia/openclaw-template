import { resolveBrowserShareCredential } from './share.mjs';

// Durable intent is written atomically with lease release by task-control.
// Only the existing Channel command lane starts another Run. No client needs
// to remain connected and an ambiguous HTTP response is retried with the same ID.
export function createHandbackDelivery({ taskControl, work, env = process.env, fetchImpl = fetch, credentialScope = globalThis }) {
  let running;
  async function deliver() {
    for (const item of taskControl.pendingHandbacks()) {
      const task = work.status(item.sessionKey, { browserTaskId: item.browserTaskId });
      if (!task || !task.needsContinuation || ['cancelled', 'expired'].includes(task.phase)) {
        taskControl.settleHandback(item.handoffId, 'cancelled'); continue;
      }
      const sessionId = /:oneclaw:direct:(session_[A-Za-z0-9_-]+)$/.exec(item.sessionKey)?.[1];
      const runtimeId = env.ONECLAW_RUNTIME_ID || env.ONECLAW_INSTANCE_ID;
      if (!sessionId || !runtimeId || !env.ONECLAW_API_URL) continue;
      const url = new URL(env.ONECLAW_API_URL);
      if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) continue;
      url.pathname = `${url.pathname.replace(/\/$/, '') || '/api/v1'}/runtime/channel/browser-handbacks`;
      const credential = resolveBrowserShareCredential(env, credentialScope);
      try {
        const response = await fetchImpl(url, {
          method: 'POST', redirect: 'error', signal: AbortSignal.timeout(8000),
          headers: { Authorization: credential.authorizationHeader(), 'X-OneClaw-Instance-ID': runtimeId, 'Content-Type': 'application/json' },
          body: JSON.stringify({ sessionId, runId: item.runId, browserTaskId: item.browserTaskId, handoffId: item.handoffId }),
        });
        const result = await response.json();
        if (response.ok && result.accepted === true) taskControl.settleHandback(item.handoffId, 'accepted');
        else if (['browser_task_cancelled', 'browser_task_superseded'].includes(result.error?.code || result.code)) taskControl.settleHandback(item.handoffId, 'cancelled');
      } catch { /* Keep durable intent; never manufacture success or replay page input. */ }
    }
  }
  const tick = () => (running ??= deliver().finally(() => { running = undefined; }));
  const timer = setInterval(() => { void tick().catch(() => {}); }, 2000);
  timer.unref();
  return { tick, close: () => clearInterval(timer) };
}
