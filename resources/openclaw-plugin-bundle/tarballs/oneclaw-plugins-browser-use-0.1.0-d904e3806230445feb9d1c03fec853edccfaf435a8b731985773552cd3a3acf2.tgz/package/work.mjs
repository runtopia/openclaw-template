import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
const PAGE_ACTIONS = new Set([
  "focus",
  "close",
  "snapshot",
  "screenshot",
  "navigate",
  "act",
  "pdf",
  "console",
  "upload",
  "dialog",
  "resize",
  "download",
  "waitfordownload",
]);
const ID = /^[A-Za-z0-9_-]{1,128}$/;
const TERMINAL = new Set(["completed", "failed", "cancelled"]);
export function browserDisplayUrl(value) {
  try {
    const url = new URL(value);
    if (url.protocol === "about:")
      return url.pathname === "blank" ? "about:blank" : undefined;
    return ["https:", "http:"].includes(url.protocol) ? url.origin : undefined;
  } catch {
    return undefined;
  }
}

/** A conversation may contain many independently addressable browser tasks. */
export function createBrowserWork({ file, now = Date.now } = {}) {
  const tasks = new Map(),
    sessions = new Map(),
    planning = new Map(),
    pendingCalls = new Map();
  const generation = crypto.randomUUID();
  let current,
    emptySince,
    revision = 0;
  const key = (context) => context?.sessionKey || context?.sessionId || "";
  const copy = (task) => {
    if (!task) return null;
    const { targets, calls, runs, finalFrame, pageUrls, ...result } = task;
    result.pages = task.targets.map((targetId) => ({
      targetId,
      displayUrl: task.pageUrls?.[targetId],
    }));
    result.previewRunId = task.runId;
    if (!task.needsContinuation || task.resourceState !== "live")
      delete result.runId;
    return result;
  };
  if (file && fs.existsSync(file)) {
    try {
      const saved = JSON.parse(fs.readFileSync(file, "utf8"));
      for (const item of (saved.tasks || saved.sessions || []).slice(-128)) {
        if (typeof item.sessionKey !== "string" || !ID.test(item.targetId))
          continue;
        const task = {
          ...item,
          browserTaskId: ID.test(item.browserTaskId || "")
            ? item.browserTaskId
            : crypto.randomUUID(),
          generation,
          displayUrl: browserDisplayUrl(item.displayUrl),
          phase: "expired",
          resourceState: "expired",
          targets: [],
          calls: Array.isArray(item.calls) ? item.calls : [],
          runs: Array.isArray(item.runs) ? item.runs : [],
          needsContinuation: false,
        };
        tasks.set(task.browserTaskId, task);
        sessions.set(task.sessionKey, task);
        current = task;
      }
    } catch {
      /* Unknown live pages are never reclaimed by this registry. */
    }
  }
  function persist() {
    revision++;
    if (!file) return;
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const temp = `${file}.${process.pid}.tmp`;
    fs.writeFileSync(
      temp,
      JSON.stringify({
        generation,
        tasks: [...tasks.values()].map(
          ({ finalFrame, ...metadata }) => metadata,
        ),
      }),
      { mode: 0o600 },
    );
    fs.renameSync(temp, file);
  }
  function resolve(sessionKey, selector = {}) {
    let candidates = [...tasks.values()].filter(
      (t) => t.sessionKey === sessionKey,
    );
    if (selector.browserTaskId)
      candidates = candidates.filter(
        (t) => t.browserTaskId === selector.browserTaskId,
      );
    else if (selector.toolCallId)
      candidates = candidates.filter((t) =>
        t.calls.includes(selector.toolCallId),
      );
    else if (Array.isArray(selector.runIds))
      candidates = candidates.filter((t) =>
        t.runs.some((r) => selector.runIds.includes(r)),
      );
    else return sessions.get(sessionKey);
    return candidates.length === 1 ? candidates[0] : undefined;
  }
  function prepare(params, context) {
    const sessionKey = key(context),
      bound = sessions.get(sessionKey);
    if (params.action === "open" && tasks.size >= 128) {
      const old = [...tasks.values()].find((t) => t.resourceState !== "live");
      if (!old)
        throw new Error(
          "Browser Use: too many live browser tasks. Close an existing task first.",
        );
      tasks.delete(old.browserTaskId);
      if (sessions.get(old.sessionKey) === old) sessions.delete(old.sessionKey);
    }
    if (!PAGE_ACTIONS.has(params.action)) return params;
    const targetId =
      params.targetId ||
      params.request?.targetId ||
      (bound?.resourceState === "live" ? bound.targetId : undefined);
    if (!targetId || !ID.test(targetId))
      throw new Error(
        "Browser Use: select a task tab explicitly with targetId, or open a new task tab first. Do not use the shared browser default tab.",
      );
    if (/^t\d+$/i.test(targetId))
      throw new Error(
        `Browser Use: compact tab aliases cannot verify task ownership. Use a full targetId${bound?.resourceState === "live" && !/^t\d+$/i.test(bound.targetId || "") ? `, such as this task's ${bound.targetId}` : " from browser open/tabs"}.`,
      );
    for (const task of tasks.values())
      if (task.sessionKey !== sessionKey && task.targets.includes(targetId))
        throw new Error(
          "Browser Use: this tab belongs to another conversation. Open a separate task tab.",
        );
    return {
      ...params,
      targetId,
      ...(params.request ? { request: { ...params.request, targetId } } : {}),
    };
  }
  function noteCall(event, context) {
    const call = event.toolCallId || context?.toolCallId;
    if (event.toolName !== "browser" || !call) return;
    const runKey = JSON.stringify([
      key(context),
      event.runId || context?.runId,
    ]);
    const calls = pendingCalls.get(runKey) || [];
    if (!calls.includes(call)) calls.push(call);
    pendingCalls.set(runKey, calls.slice(-256));
  }
  function complete(event, context, controlMode = "ai") {
    const sessionKey = key(context),
      params = event.params || {},
      details = event.result?.details || {};
    if (
      !sessionKey ||
      event.toolName !== "browser" ||
      details.status === "blocked" ||
      details.deniedReason === "plugin-before-tool-call"
    )
      return;
    // Browser-wide inspection/start operations do not select or own a page.
    // In particular, tabs may echo an unused compact targetId from the model.
    if (params.action !== "open" && !PAGE_ACTIONS.has(params.action)) return;
    const failed = Boolean(event.error || event.result?.isError),
      runId = event.runId || context?.runId;
    let prior = sessions.get(sessionKey);
    if (params.action === "close" && !failed) {
      for (const task of tasks.values())
        if (
          task.sessionKey === sessionKey &&
          task.targets.includes(params.targetId)
        )
          closeTarget(task, params.targetId);
      persist();
      return;
    }
    const targetId = details.targetId || params.targetId || prior?.targetId;
    if (!targetId || !ID.test(targetId)) return;
    // Bare focus responses cannot establish ownership of a compact alias.
    // Only canonical target evidence can create or transfer a live page.
    if (/^t\d+$/i.test(targetId) && !details.targetId) return;
    // Only explicit continuation reuses task identity. Ordinary new runs get a new task.
    if (
      !prior ||
      prior.resourceState !== "live" ||
      (runId && prior.runId !== runId && !prior.needsContinuation)
    ) {
      prior = {
        browserTaskId: crypto.randomUUID(),
        generation,
        sessionKey,
        targets: [],
        calls: [],
        runs: [],
        createdAt: now(),
        retained: false,
      };
      tasks.set(prior.browserTaskId, prior);
      sessions.set(sessionKey, prior);
    }
    // Reusing a page transfers the live resource, never the historical identity or frame.
    for (const task of tasks.values())
      if (task !== prior && task.targets.includes(targetId)) {
        prior.retained ||= task.retained;
        closeTarget(task, targetId, "archived");
      }
    noteCall(event, context);
    for (const call of pendingCalls.get(JSON.stringify([sessionKey, runId])) ||
      [])
      if (!prior.calls.includes(call)) prior.calls.push(call);
    const callId = event.toolCallId || context?.toolCallId;
    if (callId && !prior.calls.includes(callId)) prior.calls.push(callId);
    if (runId && !prior.runs.includes(runId)) prior.runs.push(runId);
    Object.assign(prior, {
      runId,
      targetId,
      targets: [...new Set([...prior.targets, targetId])],
      resourceState: "live",
      generation,
      needsContinuation:
        controlMode !== "ai" && prior.needsContinuation === true,
      displayUrl: browserDisplayUrl(details.url) || prior.displayUrl,
      phase: failed ? "failed" : "working",
      action: params.action,
      updatedAt: now(),
    });
    prior.pageUrls = { ...prior.pageUrls, [targetId]: prior.displayUrl };
    current = prior;
    persist();
  }
  function closeTarget(task, targetId, state = "expired") {
    task.targets = task.targets.filter((id) => id !== targetId);
    if (!task.targets.length) {
      task.resourceState = state;
      task.needsContinuation = false;
      if (state === "expired") task.phase = "expired";
    } else if (task.targetId === targetId) task.targetId = task.targets.at(-1);
    task.updatedAt = now();
    if (![...tasks.values()].some((t) => t.targets.length)) emptySince = now();
  }
  function finish(event, context) {
    const sessionKey = key(context),
      task = sessions.get(sessionKey);
    pendingCalls.delete(JSON.stringify([sessionKey, context?.runId]));
    if (!context?.runId || planning.get(sessionKey) === context.runId)
      planning.delete(sessionKey);
    if (
      !task ||
      task.resourceState !== "live" ||
      (context?.runId && context.runId !== task.runId)
    ) {
      persist();
      return;
    }
    task.phase = /abort|cancel/i.test(event.error || "")
      ? "cancelled"
      : task.needsContinuation
        ? "waiting_user"
        : event.success === false
          ? "failed"
          : "completed";
    if (task.phase !== "waiting_user") task.needsContinuation = false;
    task.updatedAt = now();
    persist();
  }
  function touch(context) {
    if (key(context)) planning.set(key(context), context?.runId);
  }
  function retain() {
    for (const task of tasks.values())
      if (task.targets.length) task.retained = true;
    if (current) {
      current.needsContinuation =
        ["working", "waiting_user"].includes(current.phase) ||
        planning.has(current.sessionKey);
      if (planning.get(current.sessionKey)) {
        current.runId = planning.get(current.sessionKey);
        if (!current.runs.includes(current.runId))
          current.runs.push(current.runId);
      }
    }
    persist();
  }
  function waiting(context) {
    const task = sessions.get(key(context));
    if (!task || task.resourceState !== "live") return;
    task.phase = "waiting_user";
    task.needsContinuation = true;
    persist();
  }
  function lifecycle(idleMs) {
    const live = [...tasks.values()].filter((t) => t.targets.length);
    const blockedReason =
      idleMs <= 0
        ? "disabled"
        : planning.size
          ? "running"
          : live.some((t) => !TERMINAL.has(t.phase))
            ? "unfinished_task"
            : live.some((t) => t.retained)
              ? "retained_pages"
              : null;
    const idleSince = live.length
      ? Math.max(...live.map((t) => Math.max(t.updatedAt, t.lastViewedAt || 0)))
      : (emptySince ?? null);
    return {
      blockedReason,
      idleSince,
      expiresAt:
        !blockedReason && idleSince !== null ? idleSince + idleMs : null,
      liveTasks: live.length,
    };
  }
  function idleCandidate(idleMs) {
    const state = lifecycle(idleMs);
    if (
      state.blockedReason ||
      state.expiresAt === null ||
      now() < state.expiresAt
    )
      return null;
    return {
      revision,
      targetIds: [...tasks.values()].flatMap((t) => t.targets),
    };
  }
  function expire() {
    for (const task of tasks.values()) {
      task.phase = "expired";
      task.resourceState = "expired";
      task.targets = [];
      task.needsContinuation = false;
    }
    persist();
  }
  function select(sessionKey, selector) {
    const task = resolve(sessionKey, selector);
    if (!task || task.resourceState !== "live")
      throw new Error("This browser task has no live page");
    current = task;
    task.updatedAt = now();
    persist();
    return copy(task);
  }
  function nativeStatus(sessionId, selector) {
    if (!/^session_[A-Za-z0-9_-]{1,128}$/.test(sessionId || "")) return null;
    const keys = [...sessions.keys()].filter((k) =>
      k.endsWith(`:oneclaw:direct:${sessionId}`),
    );
    return keys.length === 1 ? copy(resolve(keys[0], selector)) : null;
  }
  function setRetained(sessionKey, selector, retained) {
    const task = resolve(sessionKey, selector);
    if (!task || task.resourceState !== "live" || !TERMINAL.has(task.phase))
      throw new Error("Finish this browser task before changing retention");
    task.retained = retained;
    task.updatedAt = now();
    persist();
    return copy(task);
  }
  function saveFrame(sessionKey, selector, frame) {
    const task = resolve(sessionKey, selector);
    if (
      !task ||
      frame.targetId !== task.targetId ||
      frame.generation !== task.generation ||
      !/^data:image\/jpeg;base64,[A-Za-z0-9+/=]+$/.test(frame.image || "") ||
      frame.image.length > 700000
    )
      return;
    task.finalFrame = frame;
    if (file) {
      const destination = path.join(
        file + ".frames",
        task.browserTaskId + ".json",
      );
      fs.mkdirSync(path.dirname(destination), { recursive: true });
      const temp = destination + "." + process.pid + ".tmp";
      fs.writeFileSync(temp, JSON.stringify(frame), { mode: 0o600 });
      fs.renameSync(temp, destination);
    }
    persist();
  }
  function adoptPages(sessionKey, selector, pages) {
    const task = resolve(sessionKey, selector);
    if (!task || task.resourceState !== "live" || !Array.isArray(pages)) return;
    let changed = false;
    for (const page of pages.slice(0, 128)) {
      if (
        !ID.test(page.targetId || "") ||
        page.type !== "page" ||
        !task.targets.includes(page.openerId) ||
        task.targets.includes(page.targetId)
      )
        continue;
      if (
        [...tasks.values()].some(
          (other) => other !== task && other.targets.includes(page.targetId),
        )
      )
        continue;
      task.targets.push(page.targetId);
      task.pageUrls = {
        ...task.pageUrls,
        [page.targetId]: browserDisplayUrl(page.url),
      };
      task.targetId = page.targetId;
      task.displayUrl = browserDisplayUrl(page.url);
      changed = true;
    }
    if (changed) {
      task.updatedAt = now();
      persist();
    }
  }
  function selectTarget(sessionKey, selector, targetId) {
    const task = resolve(sessionKey, selector);
    if (
      !task ||
      task.resourceState !== "live" ||
      !task.targets.includes(targetId)
    )
      throw new Error("Page does not belong to this task");
    task.targetId = targetId;
    task.displayUrl = task.pageUrls?.[targetId];
    task.updatedAt = now();
    persist();
    return copy(task);
  }
  return {
    adoptPages,
    selectTarget,
    retainTask: (sessionKey, browserTaskId) => {
      const task = resolve(sessionKey, { browserTaskId });
      if (task) {
        task.retained = true;
        task.needsContinuation = ["working", "waiting_user"].includes(
          task.phase,
        );
        persist();
      }
    },
    noteCall,
    prepare,
    complete,
    finish,
    touch,
    retain,
    waiting,
    idleCandidate,
    lifecycle,
    expire,
    select,
    nativeStatus,
    setRetained,
    saveFrame,
    viewed: (taskId) => {
      const task = tasks.get(taskId);
      if (task?.resourceState === "live") task.lastViewedAt = now();
    },
    idleTasks: (idleMs) =>
      idleMs > 0
        ? [...tasks.values()]
            .filter(
              (t) =>
                t.resourceState === "live" &&
                TERMINAL.has(t.phase) &&
                !t.retained &&
                !planning.has(t.sessionKey) &&
                now() - Math.max(t.updatedAt, t.lastViewedAt || 0) >= idleMs,
            )
            .map(copy)
        : [],
    targets: (sessionKey, selector) => [
      ...(resolve(sessionKey, selector)?.targets || []),
    ],
    frame: (sessionKey, selector) => {
      const task = resolve(sessionKey, selector);
      if (!task) return;
      if (!task.finalFrame && file) {
        try {
          task.finalFrame = JSON.parse(
            fs.readFileSync(
              path.join(file + ".frames", task.browserTaskId + ".json"),
              "utf8",
            ),
          );
        } catch {
          return;
        }
      }
      return task.finalFrame;
    },
    status: (sessionKey, selector) =>
      copy(sessionKey ? resolve(sessionKey, selector) : current),
    list: (sessionKey) =>
      [...tasks.values()].filter((t) => t.sessionKey === sessionKey).map(copy),
  };
}
