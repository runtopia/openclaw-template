---
name: browser-use
description: 在 OneClaw 云端使用可实时预览、可人工接管的受管浏览器，执行网页交互、登录后的操作和截图。需要用户观看或接管时使用；普通资料搜索仍使用已有搜索工具。
---

# Browser Use

Runtime 已安装并管理有界面的 Chromium。使用原生 `browser` 工具，固定 `profile:"openclaw"`、`target:"host"`。不要创建另一套浏览器或绕过控制权检查。

## 环境约定

- 必须有界面启动，不能使用 headless 模式、`--headless` 或 headless 的 Ozone 后端。
- 启动 Chromium 的 **Gateway 进程**必须继承 `DISPLAY=:99` 和 `OPENCLAW_BROWSER_HEADLESS=0`。Xvfb 与 VNC 都使用 `:99`；不要修改显示编号。
- Runtime 已准备这些设置。不要自行启动 Chromium、Playwright/Puppeteer 浏览器，不安装浏览器或扩展，不修改 `openclaw.json` 来绕过启动问题。
- 在另一个 exec shell 中设置 DISPLAY 不会改变已经运行的 Gateway。发现不一致时报告 Runtime 环境问题，不能靠切换无头模式继续。

## 网页操作

正常运行时复用同一个 Chromium 实例。优先复用当前任务的标签页，不关闭用户或其他任务的标签页；任务完成不主动停止整个浏览器。关闭预览连接不会关闭浏览器，但系统清理或容器重启后不能保证标签页恢复。

1. 开始任务先用 `browser` 的 `status`/`tabs` 查看状态；未运行时使用 `start`。所有调用都使用上述 profile 和 target。
2. 打开或选定任务标签页，保存工具返回的目标标识。先获取 `snapshot`，再使用其引用执行点击、输入等操作；页面变化后重新获取快照。
3. 需要截图时使用原生 `screenshot`。截图工具结果不等于已经发给用户；通过当前渠道提供的消息或 Artifact 能力交付。
4. 多标签操作需要用户观看时，显式聚焦任务标签页；VNC 展示的是当前前台窗口。

只查公开资料时可使用 `web_search`/`web_fetch`，不必打开浏览器。需要登录态、点击、填写、截图或实时观看时，使用上述受管浏览器。

## 人工接管

需要用户登录、输入验证码或完成其他人工步骤时，引导其打开 Runtime 的 `/browser/` 页面，点击“接管浏览器”。平台可提供一次性登录链接；不要猜测域名或向用户暴露实例 Secret、Gateway Token。

- 收到 human/waiting/paused 或控制权拒绝时，停止受管浏览器操作，不反复重试，不改用 exec、其他 MCP、CLI 或直接 CDP。
- 不擅自替用户交还控制权。断线不等于交还；请用户重新连接后明确选择继续接管或交还。
- 交还后重新列出标签页并获取成功的新 snapshot，丢弃旧引用，再继续工作。
- 交还的是浏览器控制权，不会自动重新启动已经结束的聊天轮次；必要时告诉用户发送“继续”。

## 失败处理

- 启动失败：检查 `status`/`doctor`，最多重试一次暂态故障。报告浏览器/显示服务的具体错误，不加无头参数、不重装浏览器、不循环重启 Gateway。
- `start`/`tabs` 成功但导航失败：区分网络或站点问题与 SSRF 拦截。Fake-IP `198.18.x.x` 需要网络侧处理，不能关闭导航保护或硬编码猜测的 IP。
- 当前配置或工具不支持受管 profile 时，说明阻塞项；不要偷偷改成 sandbox、远程节点或另一 profile。
