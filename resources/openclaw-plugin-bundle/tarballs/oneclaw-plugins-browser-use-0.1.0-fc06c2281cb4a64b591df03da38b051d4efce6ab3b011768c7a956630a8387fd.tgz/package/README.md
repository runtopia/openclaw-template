# Browser Use

Independent Gateway plugin for Web/Desktop browser handoff. Does not require OneClaw Channel or patch OpenClaw core.

- `before_tool_call` closes admission to native browser, exec, process, gateway and nodes calls before takeover.
- Tracks in-flight managed calls, drains them before grant, and requires a new successful browser snapshot after handback.
- `browseruse.control` is operator.admin only. The Runtime Wrapper owns VNC input transport and must terminate that transport before release/recover.
- State persists privately under `$OPENCLAW_STATE_DIR/browser-use/control.json`. Restart during handoff stays paused. Unfinished leases never expire into an unsafe grant.
- OpenClaw 2026.7.1-2 `tools.invoke` dispatches before hooks without guaranteed after hooks. Unscoped managed calls are explicitly rejected; normal agent runs and Wrapper's tracked browser start are supported.

## Boundary

This coordinates cooperative managed Agent browser use, not arbitrary processes with access to the container. Direct admin browser.request/CLI/CDP, other MCP browser tools and scripts detached outside the managed exec lifecycle are outside interception. Do not advertise full isolation from code execution. A stuck/missing after hook holds takeover closed and needs investigation; this plugin does not silently drop active leases.

A blocked tool does not suspend/resume an entire conversational turn. Once the human returns control, running agents can obtain a fresh snapshot and proceed; an already-ended conversation requires a new continue message. Channel/task resume integration is separate.

## Development integration

Canonical source lives here. While testing the feature branch, copy this directory into a development image at `/opt/openclaw-browser-use` (owned by root or the Runtime user), and set `ONECLAW_BROWSER_USE_ENABLED=1` in the matching Template feature build. This is a development image, not an npm release or production bundle change. Follow repository release/bundle rules when integrating into develop.

Run `npm test` in this package.
