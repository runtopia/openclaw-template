import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

export const MANAGED_TOOLS = new Set(['browser', 'exec', 'process', 'gateway', 'nodes']);
const REOBSERVE_ACTIONS = new Set(['status', 'doctor', 'start', 'tabs', 'snapshot', 'screenshot']);
const hash = (value) => crypto.createHash('sha256').update(value).digest('hex');

// One authority per Runtime. Unknown/crashed in-flight operations never expire
// into permission to type; recovery must be an explicit administrative action.
export function createControl({ file, now = Date.now }) {
  let data = { mode: 'ai', epoch: 0, ownerHash: null, active: {} };
  const observed = new Map();
  if (fs.existsSync(file)) {
    try {
      const saved = JSON.parse(fs.readFileSync(file, 'utf8'));
      if (!['ai', 'waiting', 'human', 'paused'].includes(saved.mode) || !Number.isInteger(saved.epoch) || !saved.active || typeof saved.active !== 'object') throw new Error('Invalid control state');
      data = saved;
      if (data.mode !== 'ai' || Object.keys(data.active).length) data.mode = 'paused';
    } catch { data = { mode: 'paused', epoch: 1, ownerHash: null, active: { unknown: { tool: 'unknown' } } }; }
  }
  function persist() {
    fs.mkdirSync(path.dirname(file), { recursive: true });
    const temp = `${file}.${process.pid}.tmp`;
    fs.writeFileSync(temp, JSON.stringify(data), { mode: 0o600 });
    fs.renameSync(temp, file);
  }
  persist();
  function status() {
    return { mode: data.mode, epoch: data.epoch, inFlight: Object.keys(data.active).length, tools: [...new Set(Object.values(data.active).map((x) => x.tool))] };
  }
  function requireOwner(token) {
    if (typeof token !== 'string' || !data.ownerHash || hash(token) !== data.ownerHash) throw new Error('Browser control belongs to another connection');
  }
  function keyOf(event, context = {}) {
    const call = event.toolCallId || context.toolCallId;
    if (!call) throw new Error('Browser Use requires a stable tool call id');
    return JSON.stringify([event.runId || context.runId || '', context.sessionKey || context.sessionId || '', call]);
  }
  function begin(event, context = {}) {
    if (!MANAGED_TOOLS.has(event.toolName)) return;
    const drainingPoll = data.mode === 'waiting' && event.toolName === 'process' && event.params?.action === 'poll' && Object.values(data.active).some((call) => call.background === event.params?.sessionId);
    if (data.mode !== 'ai' && !drainingPoll) throw new Error('Browser Use: human control is pending or active. Do not retry browser/exec operations or bypass through CDP. Wait for the user to return control.');
    const session = context.sessionKey || context.sessionId || '';
    const action = event.params?.action;
    if (event.toolName === 'browser' && data.epoch > 0 && !REOBSERVE_ACTIONS.has(action) && observed.get(session) !== data.epoch) {
      throw new Error('Browser Use: control returned. Obtain a new browser snapshot before performing actions; previous refs may be stale.');
    }
    const key = keyOf(event, context);
    if (data.active[key]) throw new Error('Duplicate managed tool execution');
    data.active[key] = { tool: event.toolName, action, processSession: event.params?.sessionId, session, epoch: data.epoch, at: now() };
    try { persist(); } catch (err) { data.mode = 'paused'; throw err; }
  }
  function end(event, context = {}) {
    if (!MANAGED_TOOLS.has(event.toolName)) return;
    let key;
    try { key = keyOf(event, context); } catch { return; }
    const call = data.active[key];
    if (!call) return;
    const details = event.result?.details;
    if (call.tool === 'exec' && details?.status === 'running') {
      call.background = details.sessionId || 'unknown';
      persist();
      return;
    }
    delete data.active[key];
    if (call.tool === 'process' && call.action === 'poll' && ['completed', 'failed'].includes(details?.status) && details.sessionId === call.processSession) {
      for (const [id, running] of Object.entries(data.active)) {
        if (running.background === details.sessionId && running.session === call.session) delete data.active[id];
      }
    }
    if (call.tool === 'browser' && call.action === 'snapshot' && !event.error && !event.result?.isError && call.epoch === data.epoch) observed.set(call.session, data.epoch);
    persist();
  }
  function command(params) {
    const { action, token } = params || {};
    if (action === 'status') return status();
    if (action === 'admin-begin' || action === 'admin-end') {
      if (typeof params.callId !== 'string' || params.callId.length > 100) throw new Error('Invalid call id');
      const event = { toolName: 'browser', params: { action: 'start' }, toolCallId: params.callId, runId: 'wrapper' };
      if (action === 'admin-begin') begin(event, { sessionKey: 'wrapper' });
      else end(event, { sessionKey: 'wrapper' });
      return status();
    }
    if (action === 'request') {
      if (data.mode !== 'ai') throw new Error('Browser is already reserved; recover or release the existing session');
      if (typeof token !== 'string' || token.length < 32) throw new Error('Invalid controller token');
      data.mode = 'waiting'; data.ownerHash = hash(token); persist();
    } else if (action === 'grant') {
      requireOwner(token);
      if (data.mode !== 'waiting' || Object.keys(data.active).length) throw new Error('Waiting for in-flight operations to finish');
      data.mode = 'human'; persist();
    } else if (action === 'resume') {
      requireOwner(token);
      if (data.mode !== 'paused' || Object.keys(data.active).length) throw new Error('Only a drained, paused browser can resume human control');
      data.mode = 'human'; persist();
    } else if (action === 'pause') {
      requireOwner(token); data.mode = 'paused'; persist();
    } else if (action === 'release') {
      requireOwner(token);
      if (Object.keys(data.active).length) throw new Error('In-flight operations remain; refusing to release control');
      data.mode = 'ai'; data.ownerHash = null; data.epoch++; persist();
    } else if (action === 'recover') {
      // Caller must stop the writable VNC process first. Recovery does not
      // discard unknown leases: a stuck tool requires operator investigation.
      if (data.mode !== 'paused' || Object.keys(data.active).length) throw new Error('Only a paused, drained browser can be recovered');
      data.mode = 'ai'; data.ownerHash = null; data.epoch++; persist();
    } else throw new Error('Unknown Browser Use command');
    return status();
  }
  return { status, begin, end, command };
}
