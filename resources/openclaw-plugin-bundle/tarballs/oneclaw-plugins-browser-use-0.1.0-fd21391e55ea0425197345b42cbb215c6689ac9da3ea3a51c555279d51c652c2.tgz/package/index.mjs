import os from 'node:os';
import { createBrowserShareTool } from './share.mjs';
import path from 'node:path';
import { processControl, MANAGED_TOOLS } from './control.mjs';
import { BROWSER_USE_GUIDANCE, managedBrowserParams } from './policy.mjs';
import { createBrowserWork } from './work.mjs';
import { createTaskFocus } from './focus.mjs';
import crypto from 'node:crypto';

export function registerBrowserUse(api, control, { focus = createTaskFocus(), workFile, idleMs = 1800000 } = {}) {
  const work = control.work ??= createBrowserWork({ file: workFile });
  api.on('before_tool_call', (event, context) => {
    if (MANAGED_TOOLS.has(event.toolName) && !(event.runId || context?.runId)) {
      return { block: true, blockReason: 'Browser Use requires a managed agent run with completion hooks; unscoped tools.invoke is not supported for browser/exec control.' };
    }
    try {
      const managed = managedBrowserParams(event);
      const params = managed ? work.prepare(managed, context) : undefined;
      control.begin(params ? { ...event, params } : event, context);
      if (params?.targetId && ['snapshot', 'screenshot', 'navigate', 'act'].includes(params.action)) {
        return focus({ ...event, params }, context).then(() => ({ params })).catch((error) => {
          if (error.browserOperationUncertain) control.uncertain({ ...event, params }, context);
          else control.end({ ...event, params, error: 'Task tab focus failed' }, context);
          return { block: true, blockReason: error.browserOperationUncertain
            ? 'Browser Use: task focus completion is unknown. AI control is paused for Runtime recovery; do not bypass this state.'
            : 'Browser Use: task tab could not be focused. List tabs and select a valid targetId before continuing.' };
        });
      }
      return params ? { params } : undefined;
    }
    catch (err) { return { block: true, blockReason: err.message }; }
  }, { priority: -100000 });
  api.on('after_tool_call', (event, context) => { control.end(event, context); work.complete(event, context); });
  api.on('agent_end', (event, context) => work.finish(event, context));
  api.on('before_prompt_build', (_event, context) => {
    work.touch(context);
    const { mode, epoch, inFlight } = control.status();
    return { appendSystemContext: `${BROWSER_USE_GUIDANCE}\nCurrent Browser Use control state: ${JSON.stringify({ mode, epoch, inFlight })}. This live state supersedes earlier chat statements about control. When mode is ai, proceed with the browser task. When mode is paused, explain that AI control is paused; do not describe it as an active human session. Only waiting/human means a human takeover is pending/active.` };
  });
  api.registerGatewayMethod('browseruse.control', async ({ params, respond }) => {
    try {
      if (params?.action === 'view') {
        const browser = work.status(params.sessionKey);
        if (!params.sessionKey || !browser || browser.phase === 'expired') throw new Error('This conversation has no live browser task');
        const event = { toolName: 'browser', runId: 'viewer', toolCallId: crypto.randomUUID(), params: { action: 'focus', targetId: browser.targetId } };
        const context = { sessionKey: params.sessionKey };
        control.begin(event, context);
        try { await focus(event, context); work.select(params.sessionKey); }
        catch (error) { if (error.browserOperationUncertain) control.uncertain(event, context); throw error; }
        finally { control.end(event, context); }
        respond(true, { ...control.status(), schemaVersion: 1, browser: work.status(params.sessionKey), activeBrowser: work.status(), selectedSessionKey: params.sessionKey }); return;
      }
      const state = control.status();
      const candidate = () => idleMs > 0 && state.mode === 'ai' && state.inFlight === 0 ? work.idleCandidate(idleMs) : null;
      if (params?.action === 'idle-candidate') { respond(true, { candidate: candidate(), idleTimeoutMs: idleMs }); return; }
      if (params?.action === 'idle-begin') {
        const eligible = candidate();
        if (!eligible || eligible.revision !== params.revision) throw new Error('Browser work changed before idle suspension');
        respond(true, control.command({ action: 'admin-begin', operation: 'stop', callId: params.callId })); return;
      }
      if (['idle-end', 'idle-uncertain'].includes(params?.action)) {
        const event = { toolName: 'browser', runId: 'wrapper', toolCallId: params.callId, params: { action: 'stop' } };
        if (!control.owns(event, { sessionKey: 'wrapper' })) throw new Error('No matching idle suspension');
        if (params.action === 'idle-uncertain') control.uncertain(event, { sessionKey: 'wrapper' });
        else {
          if (params.stopped === true) work.expire();
          control.command({ action: 'admin-end', operation: 'stop', callId: params.callId });
        }
        respond(true, control.status()); return;
      }
      const activeBrowser = work.status();
      const browser = work.status(params?.sessionKey);
      const resumedWaitingTasks = ['release', 'recover'].includes(params?.action) && activeBrowser ? control.waiterCount?.(activeBrowser.sessionKey) : undefined;
      const result = control.command(params);
      if (params?.action === 'request') work.retain();
      respond(true, { ...result, ...(resumedWaitingTasks !== undefined ? { resumedWaitingTasks } : {}), schemaVersion: 1,
        browser, activeBrowser, idleTimeoutMs: idleMs, ...(params?.sessionKey ? { selectedSessionKey: params.sessionKey } : {}) });
    }
    catch (err) { respond(false, undefined, { code: 'UNAVAILABLE', message: err.message }); }
  }, { scope: 'operator.admin' });
}

export default {
  id: 'oneclaw-browser-use', name: 'Browser Use',
  register(api) {
    const control = processControl({ file: controlFile() });
    api.registerTool((context) => createBrowserShareTool(context, { control }), { name: 'browser_use' });
    const configuredIdle = Number(process.env.ONECLAW_BROWSER_IDLE_MS ?? 1800000);
    registerBrowserUse(api, control, { workFile: path.join(path.dirname(controlFile()), 'sessions.json'),
      idleMs: configuredIdle === 0 || (Number.isFinite(configuredIdle) && configuredIdle >= 60000 && configuredIdle <= 86400000) ? configuredIdle : 1800000 });
  },
};

function controlFile() {
  return path.join(process.env.OPENCLAW_STATE_DIR || path.join(os.homedir(), '.openclaw'), 'browser-use', 'control.json');
}
