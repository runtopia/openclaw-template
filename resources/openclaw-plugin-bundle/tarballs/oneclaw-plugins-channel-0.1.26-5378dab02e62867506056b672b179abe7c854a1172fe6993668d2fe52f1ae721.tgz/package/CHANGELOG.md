# Changelog

## Unreleased

- Normalize every native Cron job created through OneClaw Channel into an
  isolated, user-visible Agent run with explicit delivery to the originating
  Protocol Session, even when the model proposes an internal system event or
  disabled delivery. Other Cron creation paths retain their native semantics.
- Stop rewriting existing native Cron delivery targets during Gateway startup or
  lifecycle events; newly created OneClaw Cron jobs still bind their explicit
  Protocol Session target before the native tool call is persisted.
- Require the Agent to make a semantic Goal completion judgment and call
  `update_goal complete` before native final delivery or `NO_REPLY`, preventing
  a successfully delivered outcome from leaving the Task Dock waiting.
- Preserve the append-only answer delta cursor when tool-prelude text is
  reclassified as Commentary, preventing a repeated delta identity from
  failing an otherwise successful image or artifact Run at completion.
- Classify assistant narration immediately followed by a tool call as typed
  Commentary instead of a durable chat answer, so clients can hide internal
  setup chatter while retaining the execution trace.
- Derive execution-update identities from the complete Message snapshot so
  repeated or late tool callbacks cannot reuse an event ID with changed content
  and delay delivery of the terminal Run and Task events.
- Advance projected Task revisions when Runtime semantics change without a new
  source revision, so a same-timestamp running-to-terminal transition cannot
  leave API clients stuck on the previous running snapshot.
- Accept typed selected-filter `image.generate` interaction context and route
  it to the OneClaw image-generation skill without changing the user-authored
  message or falling back to model-native generation.
- Accept unified selected-Showcase `media.generate` context for AI Filter,
  AI Photo, and AI Video Banner entries while retaining `image.generate` compatibility.
- Add always-available `search_integrations` and `use_integration` tools so an
  Agent can discover platform-approved external capabilities, request an iOS
  authorization card when needed, and continue the same Run through the
  authenticated Runtime MCP proxy. Automatic execution remains read-only.
- Replace 250 ms empty Internal Channel v2 command polling with Redis-woken
  `wait_ms` long polling, while keeping outbound event uploads on an independent
  loop so command waits cannot delay Runtime events.

## 0.1.26 - 2026-08-18

- Replace OneClaw-created Cron `announce(last)` delivery with an explicit
  Protocol Session target so isolated scheduled runs always return to their
  originating conversation.
- Project OpenClaw's retained one-shot Cron auto-disable from the terminal
  `finished` event so API and App Plan state no longer remains active after the
  schedule expires.
- Accept the typed `plan.create` interaction hint without changing the stored
  user message, and map it to trusted OpenClaw context that prefers the native
  Cron tool while preserving explicit user instructions.
- Consume Internal Channel v2 `command.plan.run` controls through the durable
  SQLite command ledger and enqueue the authoritative native Cron job for
  immediate forced execution without waiting for the full job to finish.
- Project root Task and Cron notifications with authoritative execution and
  terminal summaries, including OpenClaw 2026.7.1 `ask_user` compatibility.
- Recover recycled SQLite WAL tails safely and preserve Cron delivery on the
  originating OneClaw session.
- Publish the matching Runtime Events SDK as `0.1.3` so the expanded Attention
  context contract remains an immutable part of the Channel release unit.

## 0.1.24 - 2026-08-14

- Move Internal Channel v2 to `/api/v2/internal/channel/*` and retain the
  frozen Protocol v1 projection consumed by released iOS clients.
- Project native Runtime Tasks and settle detached execution, media, and
  programmatic delivery lifecycles more reliably.

## 0.1.23 - 2026-08-12

- Persist authenticated inbound attachments in the selected agent workspace so
  tools can access them throughout the Run and verified retries can reuse the
  same bytes safely.

## 0.1.22 - 2026-08-12

- Authenticate attachment downloads with the active Runtime instance ID while
  keeping opaque attachment references out of URLs and logs.
- Preserve the native media completion lifecycle after reply dispatch settles.

## 0.1.20 - 2026-08-10

- Keep a native Task non-terminal when its foreground Agent Run ends while the
  Goal remains active or Goal-linked Workboard cards are non-terminal.
- Require background workers to keep Workboard status and result summaries in
  sync and delay Goal completion until every linked card is terminal.

## 0.1.19 - 2026-08-10

- Establish a core-owned Session Goal before the first native `update_plan` or
  mutating Workboard operation in a OneClaw direct task.
- Associate native Workboard roots and descendants with that Goal and project
  their real status and bounded result details into Task Dock snapshots.
- Hide internal `workboard_*` tool execution rows from public Task steps.

## 0.1.18 - 2026-08-10

- Project core-owned OpenClaw Session Goals and structured Runtime Plan steps
  into durable Protocol v1 Task snapshots without requiring Durable Work.
- Preserve native step detail, partial progress, and lifecycle summaries while
  retaining `oneclaw.tasks.get` as a compatibility fallback.

## 0.1.17 - 2026-08-10

- Accept versioned `command.plan.set-enabled` control frames and apply them to
  the authoritative native Cron service.
- Reject stale Plan revisions and rely on `cron_changed` Plan sync to confirm
  the resulting pause or resume state back to the API and App.

## 0.1.16 - 2026-08-10

- Reconcile the Runtime-authoritative native Cron inventory into OneClaw
  Workspace Plans at Gateway startup and on every Cron lifecycle mutation.
- Persist Runtime Plan sync receipts locally so API outages recover on the
  next mutation or Channel restart without requiring an active chat Run.

## 0.1.15 - 2026-08-10

- Treat the workflow Gateway surface as optional so native-orchestration hosts
  do not repeatedly request retired `oneclaw.tasks.get` or Session Actions and
  report misleading `operator.admin` scope failures.

## 0.1.14 - 2026-08-10

- Preserve distinct native assistant reply boundaries, including repeated text
  and media-only replies, without creating messages for tool-only boundaries.
- Keep replies already accepted by the native dispatcher completed when a
  later model or tool step fails.
- Route programmatic multi-media sends through the shared artifact preparation
  path so text and every uploaded media block are delivered atomically.

## 0.1.13 - 2026-08-07

- Deliver delayed native Message Tool replies after their inbound public Run
  completes by allocating an idempotent background Run bound to the same
  OneClaw Session.
- Reject cross-Session delayed delivery and preserve visible fallback text
  alongside uploaded media blocks in the atomic completed Message.

## 0.1.12 - 2026-08-07

- Correlate native Cron mutations across OpenClaw's asymmetric before/after
  tool hook contexts without relying on `channelId` after execution.
- Preserve the mutation captured before execution after the active Run is
  cleared, while rejecting unpaired or failed mutations.

## 0.1.11 - 2026-08-06

- Preserve each native assistant answer in a Run as its own ordered Protocol
  Message instead of letting the final answer replace earlier streamed output.
- Bind asynchronously delivered block replies to their upstream assistant
  message index so later answer boundaries cannot redirect older content.
- Deduplicate block delivery text already published through partial deltas in
  the authoritative completed Message snapshot.

## 0.1.10 - 2026-08-06

- Preserve trusted native Cron execution provenance across OpenClaw's shared
  `message` tool even when its best-effort queue keeps the internal delivery ID
  opaque to Channel adapters.
- Derive a stable per-execution delivery idempotency key before allocating the
  autonomous public Run and Message.
- Strip model-supplied autonomous delivery metadata outside native Cron
  executions so ordinary orphan sends remain fail-closed.

## 0.1.9 - 2026-08-06

- Bind native Cron jobs created from OneClaw conversations to the creating
  Protocol v1 Session instead of relying on OpenClaw's ambiguous `last` route.
- Allocate idempotent public Run and assistant Message identities for isolated
  Cron delivery, then publish the result through the durable Runtime Outbox.
- Preserve explicit non-OneClaw Cron delivery targets and the ordinary active
  chat Run path.

## 0.1.8 - 2026-08-05

- Project successful native OpenClaw `cron` add/update mutations as durable
  `plan.snapshot` events and removals as terminal `plan.deleted` events.
- Persist stable Plan identity, revision, latest snapshot, and pending publish
  receipts across Runtime restarts without letting failed tool calls poison
  later synchronization.
- Extend Protocol v1 and Runtime Events SDK `0.1.2` with strict Workspace Plan
  snapshots, schedules, and deletion tombstones.

## 0.1.7 - 2026-08-05

- Preserve authoritative Runtime work-item result summaries as Protocol v1
  `steps[].detail` without deriving Task state from Channel reply callbacks.

## 0.1.6 - 2026-08-05

- Resolve the Session's workflow-owned Runtime Task through
  `oneclaw.tasks.get` and translate its identity, revision, phase, plan, work
  items, and Attention summary into Protocol v1 `task.snapshot` events.
- Stop Tool, Plan, Work Item, Approval, and recovery callbacks from creating or
  terminalizing a Channel-owned Task when the Runtime Session has no Task.

## 0.1.5 - 2026-08-05

- Dispatch workflow-owned Attention responses and task cancellation through
  OpenClaw Session Actions while preserving local cancellation for ordinary
  Channel Runs.
- Stop inferring cancellation from message text and keep workflow Attention
  state authoritative instead of resolving it inside the Channel.
- Preserve retryable host failures and workflow conflict semantics in Runtime
  Channel control responses.

## 0.1.4 - 2026-08-05

- Activate the Runtime Task lifecycle only after workflow signals such as
  plans, tools, work items, or approvals, so ordinary conversations no longer
  emit `task.snapshot` events or appear in the Task Dock.
- Preserve progress and terminal snapshots after a Task has been activated.

## 0.1.3 - 2026-08-04

- Restore the OpenClaw Runtime lifecycle seam over the durable OneClaw
  transport, including settled replies, reasoning, tool traces, streaming,
  media artifacts, cancellation, and interactive Attention events.
- Publish renderer-neutral Protocol v1 message and task projections while
  retaining SQLite/WAL Inbox/Outbox recovery and idempotent public Run IDs.
- Publish the compatible `@oneclaw-plugins/runtime-events@0.1.1` SDK alongside
  the Channel package.

## 0.1.2 - 2026-08-04

- Reserved for the first Runtime-semantics migration attempt; CI correctly
  rejected publishing changed SDK contents under the already-published `0.1.0`
  version.

## 0.1.1 - 2026-08-04

- Establish the first immutable `@oneclaw-plugins/channel` npm release.
- Declare OpenClaw, Node.js, host, and Runtime Channel protocol compatibility.
- Publish `@oneclaw-plugins/runtime-events@0.1.0` as a release dependency.
