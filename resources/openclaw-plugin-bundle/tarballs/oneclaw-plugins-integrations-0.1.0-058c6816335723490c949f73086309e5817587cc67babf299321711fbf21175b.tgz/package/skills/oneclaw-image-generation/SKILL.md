---
name: oneclaw-image-generation
description: Generate an image from a source image using a OneClaw selected filter. Use whenever trusted OneClaw interaction context says image.generate with mode filter, or the user explicitly asks to create the same effect from a OneClaw filter selection.
---

# OneClaw selected-filter image generation

Use the registered `oneclaw_generate_image_by_filter` tool. Never read
`ONECLAW_INSTANCE_SECRET`, request a Pixnova key, call Pixnova MCP directly, or
substitute model-native image generation for a selected-filter request.

## Required workflow

1. Read the trusted interaction context supplied by OneClaw. It provides the
   exact `filterId` and display-only `filterName`.
2. Find the source image path from the inbound attachment annotation. Use only
   a path inside the active Agent workspace. Do not use the filter cover as the
   source image.
3. If no source image is attached, ask the user to attach one and stop. Do not
   call the tool without a source image.
4. Call the tool exactly once:

   ```json
   {
     "filterId": "TRUSTED_FILTER_ID",
     "filterName": "DISPLAY_ONLY_FILTER_NAME",
     "sourceImagePath": "/absolute/path/from/the/inbound/attachment"
   }
   ```

5. The tool uploads the source through the authenticated OneClaw API. OneClaw
   owns Credits reservation, settlement/release, provider credentials,
   generation polling, and provider error normalization.
6. On success, include the returned `imageUrl` in the final answer as one exact
   media directive on its own line:

   ```text
   MEDIA:https://returned.example/generated-image.jpg
   ```

   Add at most one short sentence before it. Do not rewrite, proxy, download,
   or alter the returned URL.

## Failure handling

- If OneClaw reports `credits_exhausted`, tell the user that OneClaw Credits are
  insufficient. Do not mention provider diamonds, VIP, or provider billing.
- If the request is unavailable or times out, state that image creation could
  not be completed and suggest retrying. Do not fall back to another image
  model unless the user explicitly abandons the selected-filter request.
- Never expose API responses, Runtime credentials, provider names, internal
  task IDs, or local filesystem paths in the final answer.
