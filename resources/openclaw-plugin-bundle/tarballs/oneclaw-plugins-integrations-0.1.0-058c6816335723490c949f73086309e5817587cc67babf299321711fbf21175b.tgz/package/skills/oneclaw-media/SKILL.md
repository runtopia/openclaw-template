---
name: oneclaw-media
description: Browse OneClaw AI Filter, AI Photo, and AI Video templates; inspect Pixnova custom models; or create through a selected template, custom model, or natural-language workbench. Use for media exploration and creation, including trusted media.generate Showcase context.
---

# OneClaw media capabilities

Use the registered `oneclaw_media` tool for discovery and selected-template requests. Never
read `ONECLAW_INSTANCE_SECRET`, request a provider key, call provider MCP tools
directly, or substitute model-native generation for an explicitly selected
OneClaw Showcase.

## Explore capabilities in chat

The capability families are:

- **AI Filter**: reproduce a selected visual style or filter from a reference
  image.
- **AI Photo**: pose, outfit, portrait, avatar, hairstyle, and similar
  photo-function workflows.
- **AI Video**: turn a source image into a selected motion or video effect.
- **Custom creation**: use a selected Seedance, Seedream, HappyHorse, or Wan
  Image model with a prompt; a source image is optional when the model permits.
- **AI workbench**: describe the desired result in natural language and let the
  service plan the compatible creation workflow; a source image is optional.

When the user asks to browse, discover, search, or see more effects, call:

```json
{
  "action": "search_templates",
  "query": "OPTIONAL_USER_KEYWORDS",
  "capability": "OPTIONAL_CAPABILITY",
  "limit": 8
}
```

`capability` may be `ai_filter`, `ai_photo`, or `ai_video`. Omit `query` to
browse. Present a short set of returned names, descriptions, capabilities, and
previews. Never invent or modify returned template IDs. Ask the user to choose
when several results fit.

## Chat-selected template workflow

After the user chooses an exact search result, preserve its returned ID, name,
and capability. Ask for one source image if none is attached, then follow the
generation call and response rules below. A result selected from
`search_templates` is an allowed template source; trusted Banner metadata is
not required for that path.

## Custom models

Call `list_custom_models` when the user wants model-based creation. Call
`get_custom_model` with an exact returned `modelKey` when model details or
available parameters are useful for explaining the model. Generation currently
uses the model defaults. Do not invent model keys.

For creation with the model defaults, call:

```json
{
  "action": "generate_custom",
  "modelKey": "EXACT_RETURNED_MODEL_KEY",
  "prompt": "USER_CREATION_PROMPT"
}
```

Include `sourceImagePath` only when the user supplied a reference image. Ask the
user to select a model first when several models fit.

## Natural-language workbench

When the user wants the service to choose the appropriate workflow from a
natural-language request, call:

```json
{
  "action": "workbench_generate",
  "prompt": "USER_CREATION_PROMPT"
}
```

Include `sourceImagePath` only if an image is attached. Do not require an image
for text-only requests.

## Generate with a selected template

1. Resolve the selection from either trusted `media.generate` interaction
   context or an exact result previously returned by `search_templates`.
   Preserve its `showcaseId`, `showcaseName`, and `capability`.
2. Find the source image path in the inbound attachment annotation. It must be
   inside the active Agent workspace. If it is missing, ask the user to attach
   an image and stop.
3. Call exactly once:

   ```json
   {
     "action": "generate_same",
     "showcaseId": "TRUSTED_SHOWCASE_ID",
     "showcaseName": "DISPLAY_ONLY_SHOWCASE_NAME",
     "capability": "ai_filter",
     "sourceImagePath": "/absolute/path/from/inbound/attachment"
   }
   ```

   `capability` may be `ai_filter`, `ai_photo`, or `ai_video`.
4. On success, include the returned `mediaUrl` as one exact media directive on
   its own line:

   ```text
   MEDIA:https://returned.example/generated-media
   ```

   Add at most one short sentence before it. Do not expose the task ID, local
   path, provider name, provider billing, or internal API response.

## Boundaries

- OneClaw API owns source upload, provider credentials, generation polling, and
  eventual Credits handling.
- Template discovery returns only OneClaw-compatible, one-source-image
  workflows and strips provider billing metadata.
- Custom model and workbench results use the same OneClaw Credits boundary;
  never mention or query Pixnova diamonds, VIP, balance, or payments.
- Provider diamonds, VIP, balance, and payment operations are never user-facing
  OneClaw capabilities.
- Do not fall back to model-native generation unless the user explicitly
  abandons the selected Showcase.
