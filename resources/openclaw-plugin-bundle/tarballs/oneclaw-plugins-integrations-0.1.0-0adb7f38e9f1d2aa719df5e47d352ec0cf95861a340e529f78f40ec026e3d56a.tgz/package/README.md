# OneClaw Integrations

OpenClaw tools for account-scoped external applications managed by the OneClaw API.

The plugin owns semantic tools, minimum-profile authorization waiting, Runtime MCP access, and provider adapters. Generic read and write capabilities can resume after the matching authorization profile is granted; destructive capabilities fail closed. Channel transport and app-facing event delivery remain in `oneclaw-channel`.
