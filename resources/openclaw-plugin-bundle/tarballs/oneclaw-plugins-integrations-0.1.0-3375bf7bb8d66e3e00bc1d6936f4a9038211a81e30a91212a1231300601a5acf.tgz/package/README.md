# OneClaw Integrations

OpenClaw tools for account-scoped external applications managed by the OneClaw API.

The plugin owns semantic tools, minimum-profile authorization waiting, Runtime MCP access, and provider adapters. Generic read and write capabilities can resume after the matching authorization profile is granted; destructive capabilities fail closed. Channel transport and app-facing event delivery remain in `oneclaw-channel`.

Connection support is layered:

- OneClaw API publishes the enabled toolkit catalog and authorization profiles.
- This plugin registers the generic `search_integrations` / `use_integration` broker and connector Skills that teach the agent safe, provider-specific workflows.
- Runtime toolkit policies impose an execution ceiling when a provider OAuth scope is broader than the product permission model. Google Ads is currently read-only even if a write capability is accidentally enabled upstream.
- The Channel plugin only transports tool and authorization events; it does not own provider registration or permissions.

Current connector Skills cover Gmail, Figma, and read-only Google Ads. X/Twitter should be added only after a managed Composio auth config is available; UI aliases alone do not make a provider authorizable.
