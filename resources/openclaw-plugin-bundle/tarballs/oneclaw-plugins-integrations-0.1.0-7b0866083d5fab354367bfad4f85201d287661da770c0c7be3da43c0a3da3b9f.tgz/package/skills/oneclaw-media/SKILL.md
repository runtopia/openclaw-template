---
name: oneclaw-media
description: Explain OneClaw AI Filter, AI Photo, and AI Video capabilities, or create the same effect from a selected media Showcase and source image. Use whenever the user asks what OneClaw media can do or trusted interaction context says media.generate with mode showcase.
---

# OneClaw media capabilities

Use the registered `oneclaw_media` tool for selected-Showcase requests. Never
read `ONECLAW_INSTANCE_SECRET`, request a provider key, call provider MCP tools
directly, or substitute model-native generation for an explicitly selected
OneClaw Showcase.

## Explore capabilities in chat

When the user asks what media creation can do, explain the current capability
families directly from this Skill:

- **AI Filter**: reproduce a selected visual style or filter from a reference
  image.
- **AI Photo**: pose, outfit, portrait, avatar, hairstyle, and similar
  photo-function workflows.
- **AI Video**: turn a source image into a selected motion or video effect.

Ask what the user wants to create and request a reference image when needed.
Do not call a template search or detail REST endpoint; the Banner is a curated
entry, while broader capability guidance belongs to this Skill.

## Selected-Showcase workflow

1. Read the trusted `media.generate` interaction context. Preserve the exact
   `showcaseId`, `showcaseName`, and `capability`.
2. Find the source image path in the inbound attachment annotation. It must be
   inside the active Agent workspace. If it is missing, ask the user to attach
   an image and stop.
3. Call exactly once:

   ```json
   {
     "action": "generate_same",
     "showcaseId": "TRUSTED_SHOWCASE_ID",
     "showcaseName": "DISPLAY_ONLY_SHOWCASE_NAME",
     "capability": "ai_filter",
     "sourceImagePath": "/absolute/path/from/inbound/attachment"
   }
   ```

   `capability` may be `ai_filter`, `ai_photo`, or `ai_video`.
4. On success, include the returned `mediaUrl` as one exact media directive on
   its own line:

   ```text
   MEDIA:https://returned.example/generated-media
   ```

   Add at most one short sentence before it. Do not expose the task ID, local
   path, provider name, provider billing, or internal API response.

## Boundaries

- OneClaw API owns source upload, provider credentials, generation polling, and
  eventual Credits handling.
- Provider diamonds, VIP, balance, and payment operations are never user-facing
  OneClaw capabilities.
- Do not fall back to model-native generation unless the user explicitly
  abandons the selected Showcase.
