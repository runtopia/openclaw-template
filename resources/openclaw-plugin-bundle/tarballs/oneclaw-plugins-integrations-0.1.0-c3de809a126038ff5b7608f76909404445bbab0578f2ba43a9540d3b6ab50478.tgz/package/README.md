# OneClaw Integrations

OpenClaw tools for account-scoped external applications managed by the OneClaw API.

The plugin owns semantic tools, authorization waiting, Runtime MCP access, and provider adapters. Channel transport and app-facing event delivery remain in `oneclaw-channel`.

