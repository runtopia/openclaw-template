# OneClaw Integrations

OpenClaw tools for account-scoped external applications managed by the OneClaw API.

The plugin owns semantic tools, minimum-profile authorization waiting, Runtime MCP access, and provider adapters. Generic read and write capabilities can resume after the matching authorization profile is granted; destructive capabilities fail closed. Channel transport and app-facing event delivery remain in `oneclaw-channel`.

Connection support is layered:

- OneClaw API publishes the enabled toolkit catalog and authorization profiles.
- This plugin registers the generic `search_integrations` / `use_integration` broker and connector Skills that teach the agent safe, provider-specific workflows.
- Runtime toolkit policies impose an execution ceiling when a provider OAuth scope is broader than the product permission model. Google Ads is currently read-only even if a write capability is accidentally enabled upstream.
- The Channel plugin only transports tool and authorization events; it does not own provider registration or permissions.

Current connector Skills cover OneClaw media capabilities and Showcase-based
generation, Gmail, Figma, read-only Google Ads, and Facebook Pages. The unified
`oneclaw_media` tool creates the same image or video effect from a selected
Showcase, while the Skill itself explains broader AI Filter, AI Photo, and AI
Video capabilities in chat. It uses the plugin-held Runtime
credential to call OneClaw API and never exposes provider credentials or
`ONECLAW_INSTANCE_SECRET` to the Agent. X/Twitter
should be added only after a managed Composio auth config is available; UI
aliases alone do not make a provider authorizable.

`oneclaw.actions.json` is the client-facing declaration for official App
entries. It contains only presentation, placement, compatibility, input, and
risk metadata. Provider routing remains in this plugin, authorization remains
in the OneClaw API, and the App never receives Skill names or MCP Tool IDs.

Safe deterministic entries may additionally declare an
`invocation.kind: "direct_action"` contract. Before prompt construction, the
plugin executes the matching provider workflow exactly once per public Run and
injects a bounded, credential-redacted result for the model to summarize. The
model does not select or repeat that tool call. Only no-input read Actions are
accepted by the v1 contract; undeclared Actions continue through the normal
model-selected tool path. The three versioned `media.generate` contracts are
the explicit write-capable exception: their prompt, mode, selected Showcase or
model, and source attachment are already fixed by trusted App metadata before
the provider call.

## Reusing connections from other chat channels

`oneclaw_gmail`, `search_integrations`, and `use_integration` can reuse the
Runtime owner's existing connections from Telegram, Discord, Slack, Feishu,
WhatsApp, WeChat, and other native channels. The OpenClaw tool context must
identify the sender as the owner (`senderIsOwner === true`) and supply an Agent
and session key. Configure owner identity in OpenClaw; pairing or allowing a
sender to chat alone does not grant access to the owner's connected accounts.
Normal host Agent/tool policies still apply. Requests and results stay in the
originating chat, so an owner invoking these tools in a group shares the result
with that group.

External-channel calls use the same broker, scoped Runtime credential,
capability checks, existing read/write profiles, and destructive-action block.
They never invent a OneClaw public Session/Run. When a connection or permission
upgrade is missing, tools immediately return `authorization_required` with
instructions to connect in OneClaw and retry in the original chat. They do not
create an authorization card or wait for an invisible card in that channel.
OneClaw public turns retain their existing authorization-and-resume workflow.

The compact connected-app prompt catalog and App action/media flows remain
bound to OneClaw public turns. Other channels discover capabilities through the
integration tool descriptions and `search_integrations`; they do not receive
all provider MCP schemas.
